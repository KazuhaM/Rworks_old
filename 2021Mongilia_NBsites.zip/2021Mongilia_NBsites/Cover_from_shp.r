library(sf)
library(sp)
library(gstat)

# set working directory
setwd("D:/OneDrive - g.ecc.u-tokyo.ac.jp/LEP/2020/00working/1301MongoliaAnalysis8/ShrubDistribution")

# sites file
sites <- read.csv("shp_forVariogram/Sites_var.csv", header = T)

# grid size
gr_size = 500 # mm
gr_size = gr_size / 1000

# site size
st_size = 20 # m

# result data frame
result.all <- data.frame("SiteID" = "base", 
                        "CoverSHP" = 0.0)
# data load
for (i_site in 1:nrow(sites)) {

# site.name <- "W2_3"
  site.name <- sites[i_site,1]
  sp_shp<-sf::st_read(paste("shp_forVariogram/05Overlay500/500", site.name, ".shp", sep = ""))

  # Cul shrub cover rate from shp
  d.z<- sp_shp[,grep("Pol_1",colnames(sp_shp))] * (gr_size^2)   # 面積算出
  d.z  <- d.z[,1]
  d.cover <- sum(d.z) / st_size^2
  
  result<- data.frame("SiteID" = site.name,
                       "CoverSHP" = d.cover)

  result.all <- rbind(result.all, result)
}
result.all <- result.all[-1,]
write.csv(result.all, "CoverSHP.csv")


##########################################################################################
# for (i_plt in 1:nrow(result)) {
#   spm.model.aniso<-vgm(psill=result[i_plt,"sill"]  ,
#                        model=result[i_plt,"model"]  ,
#                        range=result[i_plt,"range"]  ,
#                        nugget=result[i_plt,"nugget"]  ) 
#   d.aniso<- variogram(Z~X+Y,d,alpha=dir.list[i_plt], tol.hor = 90/dir.len)
#   plot(d.aniso,spm.model.aniso)
  # dev.copy(pdf,
  #          file=paste("21forVariogram/var_", site.name, "_", dir.list[i_plt] , ".pdf", sep = ""),
  #          width = 10, height = 10)
#   dev.off()
# }



# d.aniso<- variogram(Z~X+Y,d,alpha=dir.list[i], tol.hor = 90/8)
# plot(d.aniso,pch=1,cex=1.2)
# spm.model.aniso<-vgm(psill=0.09617213     ,model="Exp",range=0.6486082     , nugget=0.000,anis=c(0,0.9)) #W2_3
# # spm.model.aniso<-vgm(psill=0.01458745 ,model="Exp",range=0.2535 , nugget=0.000,anis=c(0,0.9)) # S1_1
# 
# plot(d.aniso,spm.model.aniso)
# spm.fit.aniso<-fit.variogram(d.aniso, spm.model.aniso)
# summary(spm.fit.aniso)
# spm.fit.aniso


