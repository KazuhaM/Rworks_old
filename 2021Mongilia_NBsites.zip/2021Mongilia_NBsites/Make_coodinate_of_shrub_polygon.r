library(sp)
library(tcltk2)
# 内外の判定 0 : 領域外の点 1 : 領域内の点 2 : 境界上の点(辺) 3 :境界上の点(頂点)
# res <- point.in.polygon(x, y, pol.x, pol.y)

path <- "D:/OneDrive - g.ecc.u-tokyo.ac.jp/LEP/2020/00working/1301MongoliaAnalysis8/ShrubDistribution"
setwd(path)

WsiteD <- read.csv("WsiteShrubDistribution.csv",header = T)
# WsiteD_index <- setdiff(colnames(WsiteD), c("SiteDir.E0_left.","shrub_dir.E0_left."))
# WsiteD <- WsiteD[WsiteD_index]
site_name <- as.factor(WsiteD$Site)
site_name <- levels(site_name)

# 座標、長辺短辺の長さを5400mグリッドサイズにする
WsiteD[,c("x","y","long_axis","short_axis")] <- WsiteD[,c("x","y","long_axis","short_axis")]*5400/20

# グリッドポイントの座標行列を生成
# 20mグリッドを5400mグリッドで表現する
p_grid_x <- seq(0,5400,length=21)
p_grid_y <- seq(0,5400,length=21)

# 原点からseptime分割の各方位に対して伸ばした線分のx, y座標
# 方位の分割数はseptimeで定義。sepcountsは線分の分割数
# 線分の長さはほぼ対角線と等しい
# このとき、線分を構成する点間の距離は約2.83cm (sqrt(2)/50 m)→sqrt(2)*27/5
# バリオグラム算出過程では20m四方のサイトを5400mとしているので、その補正をかける
septime <- 32
sepcounts <- 1002
linepointx <- flinepointx(septime,sepcounts)
linepointy <- flinepointy(septime,sepcounts)

# 円周上の点の座標を出すための、-180~180の角度
pori_sm <- 100
base_x <- seq(-pi, pi, length=pori_sm)


for (i in 1:length(site_name)) {
  temp_WsiteD <- WsiteD[WsiteD$Site == site_name[i],]

  shrb_px <- data.frame(matrix(rep(NA, pori_sm), nrow=1))[numeric(0), ]
  shrb_py <- data.frame(matrix(rep(NA, pori_sm), nrow=1))[numeric(0), ]
  
  # 楕円周上の点の座標を取得
  for(j in 1:nrow(temp_WsiteD)){
   
    # 長軸（半分）
    t_a <- temp_WsiteD$long_axis[j]/2
    # 短軸（半分）
    t_b <- temp_WsiteD$short_axis[j]/2
    # 回転角
    t_theta <- temp_WsiteD$shrub_dir.E0_left.[j] * pi / 180
    # 中心のx座標
    t_cenx <- temp_WsiteD$x[j]
    # 中心のy座標
    t_ceny <- temp_WsiteD$y[j]
    
    # 楕円周上の点の座標
    # 楕円の媒介変数表示に対してt_thetaの回転移動を行い、更に中心座標で平行移動
    t_x <- t_a * cos(base_x) * cos(t_theta) - t_b * sin(base_x) * sin(t_theta) + t_cenx
    t_y <- t_a * cos(base_x) * sin(t_theta) + t_b * sin(base_x) * cos(t_theta) + t_ceny
    
    t_x <- data.frame(rbind(t_x))
    row.names(t_x) <- j
    t_y <- data.frame(rbind(t_y))
    row.names(t_y) <- j
    t_y <- t_y - 5400
    
    shrb_px <- rbind(shrb_px,t_x)
    # shrb_py <- rbind(shrb_py,t_y)
    shrb_py <- rbind(shrb_py,t_y) #y軸方向に-5400平行移動
  }
  # shpファイル作成用のテキストデータ生成
  # 結果格納データフレーム
  shrb.cood.txt <- data.frame(geom = "",name = "")[0,]
   
  for (i_row in 1:nrow(shrb_px)) {
    shrb.cood.temp <- NULL
    shrb.cood.temp <- data.frame("x" = as.vector(t(shrb_px[i_row,])),
                                 "y" = as.vector(t(shrb_py[i_row,])))
    shrb.cood.temp$xy <- paste(shrb.cood.temp$x,shrb.cood.temp$y)
    shrb.cood.txt[i_row,1] <- paste("POLYGON((",
                                    paste(shrb.cood.temp$xy,collapse =","),
                                    "))",sep = "")
    shrb.cood.txt[i_row,2] <- i_row
  }
  
  
  write.csv(shrb.cood.txt, paste(site_name[i],"_PolyCoodi.csv", sep = ""),row.names=FALSE)
  print(paste(i,"/",length(site_name),"まで終了",sep ="" ))
}

flinepointx <- function(seppi,count){
  sepang <- 360/seppi
  reprang <- seq(0, 360-sepang, by = sepang)
  output <- data.frame(matrix(NA, nrow=count, ncol = seppi))
  colnames(output) <- reprang
  for(tiangx in reprang){
    output[,as.character(tiangx)] <- seq(0,length = count, by = sqrt(2)*27*cos(tiangx * pi / 180) / 5)
  }
  return(output)
}
flinepointy <- function(seppi,count){
  sepang <- 360/seppi
  reprang <- seq(0, 360-sepang, by = sepang)
  output <- data.frame(matrix(NA, nrow=count, ncol = seppi))
  colnames(output) <- reprang
  for(tiangy in reprang){
    output[,as.character(tiangy)] <- (seq(0,length = count, by = sqrt(2)*27*sin(tiangy * pi / 180) / 5))
  }
  return(output)
}
