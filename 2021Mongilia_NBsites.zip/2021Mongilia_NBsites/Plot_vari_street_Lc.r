
# library -----------------------------------------------------------------

library(sp)
library(tcltk2)
# library("fmsb")
library("RColorBrewer")
library(plotrix)
# 内外の判定 0 : 領域外の点 1 : 領域内の点 2 : 境界上の点(辺) 3 :境界上の点(頂点)
# res <- point.in.polygon(x, y, pol.x, pol.y)


# main --------------------------------------------------------------------
path <- "D:/OneDrive - g.ecc.u-tokyo.ac.jp/LEP/2020/00working/1301MongoliaAnalysis8/ShrubDistribution"
setwd(path)

# 調整項目
septime <- 30

# 単方性のstreetとLc
WDstreetLc <- read.csv("WDstreet_Lc.csv",header = T)

# バリオグラムのデータ
variall <- read.csv("all_vari.csv",header = T)
variall$SiteID  <- as.factor(variall$SiteID )
sites <- levels(variall$SiteID)
site_name <- chartr("_","-",sites)
  
variuni <- read.csv("uni_vari.csv",header = T)
variuni$SiteID <- as.factor(variuni$SiteID)
variuni$degree <- 90 - variuni$degree

for (i_site in 1:length(sites)) {
  # バリオグラムデータについて該当サイトのデータ抽出
  temp.vari.a <- variall[variall$SiteID == sites[i_site],]
  i_baseangle <- temp.vari.a$siteDir[1] - 270
  t.variuni <- variuni[variuni$SiteID == sites[i_site],]
  
  ## バリおグラムデータ調整
  # rangeは24度刻みなので、12度刻みに変換。
  # 24度刻みにない角度は、前後のデータの平均値を用いる
  plot.vari.a <- t(temp.vari.a[,c("effective_range")])
  plot.vari.a <- as.vector(plot.vari.a)
  # plot.vari.a <- c(plot.vari.a ,plot.vari.a )
  plot.vari.a2 <- result.shrb.distr <- data.frame(matrix(rep(NA, 30), nrow=1))
  plot.vari.a2[,seq(1,15,by = 2)] <- plot.vari.a
  plot.vari.b = plot.vari.a[2:length(plot.vari.a)] + plot.vari.a[-length(plot.vari.a)]
  plot.vari.a2[,seq(2,14,by = 2)] <- plot.vari.b / 2
  
  plot.vari.a2[,seq(16,30,by = 2)] <- plot.vari.a
  plot.vari.a2[,seq(17,29,by = 2)] <- plot.vari.b / 2
  plot.vari.a2 <- as.data.frame(plot.vari.a2)
  colnames(plot.vari.a2) <- seq(0,360-12,by = 12)
  plot.vari.a2 <- as.vector(plot.vari.a2)
  
  
  # streetのデータ読み込み
  wstr <- read.csv(paste("Street_Lambda/",site_name[i_site],"_avelen.csv", sep = ""),header = T)
  
  # Lcのデータ読み込み
  est_lamb <- read.csv(paste("Street_Lambda/",site_name[i_site],"_lambda.csv", sep = ""),header = T)
  
  # 単方性street, Lcの該当サイト抽出
  temp_WDsl <- WDstreetLc[WDstreetLc$site == site_name[i_site],]
  
  # streetデータ調整
  wstr <- t(wstr$result.shrb2)
  est_len <- as.vector(wstr)
  est_len <- c(est_len,est_len)
  est_len <- as.data.frame(t(est_len))
  colnames(est_len) <- seq(0, 360-360/septime, length=septime)
  est_len <- as.vector(est_len)
  
  # Lcデータ調整
  est_lamb <- t(est_lamb$lateralC)
  est_lamb <- as.vector(est_lamb)
  est_lamb <- c(est_lamb,est_lamb)
  est_lamb <- as.data.frame(t(est_lamb))
  colnames(est_lamb) <- seq(0, 360-360/septime, length=septime)
  est_lamb <- as.vector(est_lamb)
  
  ### プロット
  par(mar = c(1,1,1,1),xpd=F,family = family_serif)
  
  # バリオグラム
  radial.plot(plot.vari.a2[!is.na(plot.vari.a2)], 
              line.col = "Red",lwd = 2.5,lty = 1,
              labels = colnames(plot.vari.a2),
              rp.type="p",
              show.grid.labels = 0,
              radial.lim =seq(0,15,length = 5),
              rad.col =adjustcolor("gray", alpha=1),
              grid.col = adjustcolor("gray", alpha=1),
              start=i_baseangle*pi/180,clockwise=TRUE
              )
  text(seq(3.75,15,length = 4),0,seq(3.75,15,length = 4),cex = 1,col= "red")
  # WDごとの値をプロット
  WDr_x <- t.variuni$effective_range * cos(t.variuni$degree * pi / 180)
  WDr_y <- t.variuni$effective_range * sin(t.variuni$degree * pi / 180)
  points(WDr_x,WDr_y,pch = 16,col = "red")
  
  
  # street
  par(new = T)
  radial.plot(est_len, 
              line.col = 1,lwd = 2.5,lty = 2,
              labels = "",
              rp.type="p",
              show.grid.labels = 3,
              radial.lim =seq(0,20,length = 5),
              rad.col =adjustcolor("gray", alpha=0),
              grid.col = adjustcolor("gray", alpha=0),
              start=i_baseangle*pi/180,clockwise=TRUE
  )
  # WDごとの値をプロット
  WDs_x <- temp_WDsl$wdstreet * cos(temp_WDsl$WD.SiteUpE0left * pi / 180)
  WDs_y <- temp_WDsl$wdstreet * sin(temp_WDsl$WD.SiteUpE0left * pi / 180)
  points(WDs_x,WDs_y,pch = 16,col = 1)
  
  # Lc
  par(new = T)
  radial.plot(est_lamb, lty = 4,lwd = 2.5,
              labels = "",
              rp.type="p",line.col = 4,
              radial.lim =seq(0,0.06,length = 5),
              show.grid.labels = 0,
              rad.col =adjustcolor("gray", alpha=0),
              grid.col = adjustcolor("gray", alpha=0),
              start=i_baseangle*pi/180,clockwise=TRUE
  )
  text(-seq(0,0.06,length = 5),0,seq(0,0.06,length = 5),cex = 1,col= 4)
  # WDごとの値をプロット
  WDl_x <- temp_WDsl$lateralC * cos(temp_WDsl$WD.SiteUpE0left * pi / 180)
  WDl_y <- temp_WDsl$lateralC * sin(temp_WDsl$WD.SiteUpE0left * pi / 180)
  points(WDl_x,WDl_y,pch = 16,col =4)
  
  arrows(0, 0, cos((temp.vari.a$siteDir[1]-270) * pi / 180) * 0.06,
         sin((temp.vari.a$siteDir[1]-270) * pi / 180)* 0.06  ,angle = 15, length = 0.15,lwd = 2,
         col = "gray")
  
  dev.copy(cairo_pdf, file=paste("Sum_rosePlot_",sites[i_site],".pdf",sep=""), width = 4.5, height = 4.5)
  dev.off()
  # マーカー
  print(paste(i,"/",length(site_name),"まで終了",sep ="" ))
}


# Functions ---------------------------------------------------------------

flinepointx <- function(seppi,count,abaseangle){
  # base angleはサイト上E0leftのサイト方位を入れれば良い
  sepang <- 360/seppi
  reprang <- seq(0, 360-sepang, by = sepang)
  reprang <- reprang[1:(seppi/2)]
  output <- data.frame(matrix(NA, nrow=2*count-1, ncol = (seppi/2)))
  colnames(output) <- reprang # 出力データフレームの列名はN0rightの方位角
  reprang <- abaseangle- reprang # E0leftで表記
  i_col = 1
  for(tiangx in reprang){
    temp.line <- seq(0,length = count, by = sqrt(2)*cos(tiangx * pi / 180) / 50)
    temp.line <- c(rev(-temp.line),temp.line[2:length(temp.line)])
    output[,i_col] <- temp.line
    i_col <- i_col + 1
  }
  return(output)
}
flinepointy <- function(seppi,count,abaseangle){
  sepang <- 360/seppi
  reprang <- seq(0, 360-sepang, by = sepang)
  reprang <- reprang[1:(seppi/2)]
  output <- data.frame(matrix(NA, nrow=2*count-1, ncol = (seppi/2)))
  colnames(output) <- reprang # 出力データフレームの列名はN0rightの方位角
  reprang <- abaseangle- reprang # E0leftで表記
  i_col = 1
  for(tiangy in reprang){
    temp.line <- (seq(0,length = count, by = sqrt(2)*sin(tiangy * pi / 180) / 50))
    temp.line <- c(rev(-temp.line),temp.line[2:length(temp.line)])
    output[,i_col] <- temp.line
    i_col <- i_col + 1
  }
  return(output)
}

