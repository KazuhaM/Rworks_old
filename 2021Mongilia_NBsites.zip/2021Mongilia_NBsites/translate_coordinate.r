# working directory
path <- "D:/OneDrive - g.ecc.u-tokyo.ac.jp/LEP/2020/00working/1301MongoliaAnalysis8/ShrubDistribution/shp_forVariogram/00GPSdata_shrub/02Geometry_coordinate"
setwd(path)

# read site dir file and result file
sitedir <- read.csv("Site_dir_E0left.csv",header=T)
Ssummary <- read.csv("D:/OneDrive - g.ecc.u-tokyo.ac.jp/LEP/2020/00working/1301MongoliaAnalysis8/ShrubDistribution/WsiteShrubDistribution.csv",header=T)

# modify site dir file
sitedir$SiteDir_measuredGIS <- sitedir$SiteDir_measuredGIS * pi / 180
sitedir$Site <- as.factor(sitedir$Site)
sites <- levels(sitedir$Site)

# modify summary file
Ssummary$gpsx <- NA
Ssummary$gpsy <- NA
Ssummary$gpsz <- NA

# culculating translated coordinates
for (i_site in sites) {
  # site info
  t.sitedir <- sitedir$SiteDir_measuredGIS[sitedir$Site == i_site]
  t.siteleftup <- sitedir$leftup_gps[sitedir$Site == i_site]
  
  # site coordinate data
  t.sitename <- paste(i_site,".csv",sep="")
  t.site <- read.csv(t.sitename)
  
  # translation
  t.sitetranc <- t.site[t.site$Name==t.siteleftup, c("xcoord","ycoord")]
  t.site$xcoord <- t.site$xcoord - t.sitetranc$xcoord
  t.site$ycoord <- t.site$ycoord - t.sitetranc$ycoord
  
  # lotation
  t.sitedir <- -(pi / 2 - t.sitedir)
  t.site$xcoord.t <- t.site$xcoord * cos(t.sitedir) - t.site$ycoord * sin(t.sitedir)
  t.site$ycoord.t <- t.site$xcoord * sin(t.sitedir) + t.site$ycoord * cos(t.sitedir)
  
  t.site <- t.site[,c("Name","Elevation","xcoord.t","ycoord.t")]
  t.row <- NULL
  for (i in 1:nrow(t.site)) {
    t.row[i] <- match(t.site$Name[i],Ssummary$GPS)
  }
  t.site <- cbind(t.site, t.row)
  t.site <- t.site[!is.na(t.site$t.row),]
  # result
  Ssummary[t.site$t.row,c("gpsx","gpsy","gpsz")] <- 
          t.site[,c("xcoord.t","ycoord.t","Elevation")]
}

write.csv(Ssummary, paste("D:/OneDrive - g.ecc.u-tokyo.ac.jp/LEP/2020/00working/1301MongoliaAnalysis8/ShrubDistribution/WsiteShrubDistribution2.csv", sep = ""),row.names=FALSE)
