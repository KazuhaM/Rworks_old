#環境データ
e<-read.csv("VegCom.csv",header = T)
e
dungs.all <-e$DngH + e$DngC + e$DngS
#plot(e.dung, e$AllCov)
#result.lm<-lm(e$AllCov~e.dung)
#summary(result.lm)
#abline(result.lm)     
e<-cbind(e,dungs.all)
#pairs(e[,2:16])
#d.mds$rproj
#e.dung

com<-NULL
for (i in 1 : 5){
  com<-cbind(com,e[,2]==i)
}
com

#全種
dung.ave<-NULL
dung.se<-NULL
#com.num<-NULL
for(i in 1 :5){
  dung.ave[i] <- mean(e[com[,i],lvst])
  dung.se[i] <- sd(e[com[,i],lvst])/sqrt(length(which(com[,i] == TRUE)))
  #dung.sum[i] <- sum(e$dungs.all[com[,i]]) 
  #com.num[i]<-length(which(com[,i] == TRUE))
}
dung.ave
dung.se

#ラクダのみ
dung.ave<-NULL
dung.se<-NULL
#com.num<-NULL
for(i in 1 :5){
  dung.ave[i] <- mean(e$DngC[com[,i]])
  dung.se[i] <- sd(e$DngC[com[,i]])/sqrt(length(which(com[,i] == TRUE)))
  #dung.sum[i] <- sum(e$dungs.all[com[,i]]) 
  #com.num[i]<-length(which(com[,i] == TRUE))
}
dung.ave
dung.se
#com.no<-5
#plot(e.dung[com[,com.no]],d.mds$rproj[com[,com.no],1])
#e.dung()#

#com.no<-5
#plot(e.dung[com[,com.no]],d.mds$points[com[,com.no],1])
#e.dung()
#plot(e.dung,d.mds$points[,1])
