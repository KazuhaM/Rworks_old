
p<-read.csv("PC20.csv",header=F )
p <- p[,order(p[1,])]
colnames(p)<-p[1,]
p <- p[-1,]
p <- ts(p)

#?????ڔ򍻌v-?????v
w<-read.csv("WM20.csv",header=T)
w <- ts(w)


s <- read.csv("SiteType.csv",header = T)
s <- s[1:20,]
s <- s[order(s[,2]),]

p.m <- p[,s[,3]=="M"]
p.a <- p[,s[,3]=="A"]
p.g <- p[,s[,3]=="G"]
p.s <- p[,s[,3]=="S"]



#?O???t
win.graph(15,15)
par(mfrow = c(7,2))
for(i in 1 : 14){
  ts.plot(w[,i],xlab="",ylab= "m/s ",main=colnames(w)[i])
}
  
vt <- c(ncol(p.m),ncol(p.a),ncol(p.g),ncol(p.s))
win.graph(15,15)
par(mfrow = c(5,2))
for(i in 1 : ncol(p.m)){
  ts.plot(p.m[,i],ylab="(num)",main=colnames(p.m)[i],ylim=c(0,10000))
}
for(i in 1 : ncol(p.a)){
  ts.plot(p.a[,i],ylab="(num)",main=colnames(p.a)[i],ylim=c(0,10000))
}
for(i in 1 : 2){
  ts.plot(p.g[,i],ylab="(num)",main=colnames(p.g)[i],ylim=c(0,10000))
}

win.graph(15,15)
par(mfrow = c(5,2))

for(i in 3 : ncol(p.g)){
  ts.plot(p.g[,i],ylab="(num)",main=colnames(p.g)[i],ylim=c(0,10000))
}
for(i in 1 : ncol(p.s)){
  ts.plot(p.s[,i],ylab="(num)",main=colnames(p.s)[i],ylim=c(0,10000))
}


  ts.plot(w,xlab="",ylab= "m/s ",main="Wind speed(m/s) at 150cm height")


ts.plot(p10,xlab="", ylab="(num)",main =paste("Drifting Sand " ,base , "_10",sep=""),ylim=c(0,ceiling(max(p10[!is.na(p10)])*1.2)))
ts.plot(p20,xlab="", ylab="(num)",main =paste("Drifting Sand " ,base , "_20",sep=""),ylim=c(0,ceiling(max(p20[!is.na(p20)])*1.2)))
ts.plot(p40,xlab="", ylab="(num)",main =paste("Drifting Sand " ,base , "_40",sep=""),ylim=c(0,ceiling(max(p40[!is.na(p40)])*1.2)))
ts.plot(w25s,xlab="",ylab= "m/s ",main="Wind speed(m/s) at 25cm height")
abline(h = 4)
ts.plot(w25d,xlab="",ylab= "degree ",main="Wind direction at 25cm height")
abline(h = 120)
abline(h = 240)
ts.plot(w11s,xlab="", ylab= "m/s ",main="Wind speed(m/s) at 110cm height")
abline(h = 4)
ts.plot(w11d,xlab="", ylab= "degree ",main="Wind direction at 110cm height")
abline(h = 120)
abline(h = 240)

		dev.copy(pdf, file=paste(base,".pdf",sep=""), width = 12, height = 11)
		dev.off()

#------------------------------------------------------------------------------------------------
#CT?p


#?????ڔ򍻌v
base <- "2_CT"
pflname<-paste("p" , base ,".csv",sep="")
wflname25<-paste("w", base ,"_25.csv",sep="")
wflname11<-paste("w", base ,"_110.csv",sep="")

p<-read.csv(pflname,header=T)

p10 <- ts(p[,2])
p20 <- ts(p[,3])
p40 <- ts(p[,4])
pug <- ts(p[,5])

#?????ڔ򍻌v-?????v
w25<-read.csv(wflname25,header=T)
w25s <- ts(w25[,2])
w25d <- ts(w25[,3])

w11<-read.csv(wflname11,header=T)
w11s <- ts(w11[,2])
w11d <- ts(w11[,3])

#?O???t
win.graph(12,11)
par(mfrow = c(8,1),pin=c(8,0.3))
ts.plot(p10,xlab="", ylab="(num)",main =paste("Drifting Sand " ,base , "_10",sep=""),ylim=c(0,ceiling(max(p10[!is.na(p10)])*1.2)))
ts.plot(p20,xlab="", ylab="(num)",main =paste("Drifting Sand " ,base , "_20",sep=""),ylim=c(0,ceiling(max(p20[!is.na(p20)])*1.2)))
ts.plot(p40,xlab="", ylab="(num)",main =paste("Drifting Sand " ,base , "_40",sep=""),ylim=c(0,ceiling(max(p40[!is.na(p40)])*1.2)))
ts.plot(pug,xlab="", ylab="(num)",main =paste("Drifting Sand " ,base , "_Fixed Direction(N)",sep=""),ylim=c(0,ceiling(max(pug[!is.na(pug)])*1.2)))
ts.plot(w25s,xlab="",ylab= "m/s ",main="Wind speed(m/s) at 25cm height")
abline(h = 4)
ts.plot(w25d,xlab="",ylab= "degree ",main="Wind direction at 25cm height")
abline(h = 120)
abline(h = 240)
ts.plot(w11s,xlab="", ylab= "m/s ",main="Wind speed(m/s) at 110cm height")
abline(h = 4)
ts.plot(w11d,xlab="", ylab= "degree ",main="Wind direction at 110cm height")
abline(h = 120)
abline(h = 240)

		dev.copy(pdf, file=paste(base,".pdf",sep=""), width = 12, height = 11)
		dev.off()

