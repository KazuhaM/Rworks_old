
# パッケージインストール -------------------------------------------------------------

# install.packages("tidyverse")
# install.packages("systemfonts")
# 
# remotes::install_github("Gedevan-Aleksizde/fontregisterer", repos = NULL, type = "source")


# パッケージロード ----------------------------------------------------------------

require(tidyverse)
require(systemfonts)


# フォントの読み込みと設定 ------------------------------------------------------------

require(fontregisterer)

# windowsの通常なら游書体が登録される
if(Sys.info()["sysname"] == "Windows"){
  if(as.integer(str_extract(Sys.info()["release"], "^[0-9]+")) >=8){
    family_jsans <- "Yu Gothic"
    family_jserif <- "Yu Mincho"
    family_sans <- "Arial"
    family_serif <- "Times New Roman"
  } else {
    family_sans <- "MS Gothic"
    family_serif <- "MS Mincho"
  }
} else if(Sys.info()["sysname"] == "Linux") {
  family_sans <- "Noto Sans CJK JP"
  family_serif <- "Noto Serif CJK JP"
} else if(Sys.info()["sysname"] == "Darwin"){
  family_serif <- "Hiragino Mincho ProN"
  family_sans <- "Hiragino Sans"
} else {
  # インストールすればとりあえず動く
  family_sans <- "Noto Sans CJK JP"
  family_serif <- "Noto Serif CJK JP"
}

# 使用可能なフォントの一覧の表示
names(windowsFonts())

# フォントの指定 -----------------------------------------------------------------

par(family = family_serif)
par(family = family_sans)

