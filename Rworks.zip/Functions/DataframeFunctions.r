
# library -----------------------------------------------------------------
library(tidyverse)
library(furrr)
plan(multisession, workers = 7)
options(scipen=5)

# 処理系関数 --------------------------------------------------------------------

## 空のデータフレーム作成
createEmptyDf = function( nrow, ncol, colnames = c() ){
  data.frame( matrix( vector(), nrow, ncol, dimnames = list( c(), colnames ) ) )
}

## 総当り組み合わせのデータフレームを作成
round.robin.data <- function(data1,data2){
  
  # out.colnames <- c(colnames(data1),colnames(data2))
  nrow1 <- nrow(data1)
  nrow2 <- nrow(data2)
  data1$robnum1 <- 1:nrow1
  data2$robnum2 <- 1:nrow2
  
  
  data1.multi <- data.frame(future_map2_dfr(data1, nrow2,rep))
  data2.multi <- data.frame(future_map2_dfr(data2, nrow1,rep))
  data2.multi <- data2.multi[order(data2.multi[,"robnum2"]),]
  
  output <- data.frame(cbind(data1.multi,data2.multi))
  output <- output[,!(colnames(output) %in% c("robnum1","robnum2"))]
  
  # colnames(output) <-out.colnames
  row.names(output) <- NULL
  
  return(output)
}

# でーたふれーむの各行を要素としてリスト化
data.frame.to.list<- function(...) Map(list, ...)
