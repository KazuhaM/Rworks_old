# 数学的操作（基礎） -------------------------------------------------------------------

## 点を回転移動
# pは(x,y)のデータフレームかベクトル
# 各行が1データ(出力もそう)
# 出力はデータフレーム
point.rotate <- function(p,etheta,digits = 5){
  if(!is.vector(etheta)){
    stop("theta must be vector")
  }
  if(!(is.vector(p) | is.data.frame(p))){
    stop("p must be vector or data frame") 
  }
  p2 <- data.frame(x = p[1], y = p[2])
  output <- createEmptyDf(max(nrow(p2), length(etheta)),2,c("x","y"))
  if(nrow(p2) == 1){
    output[,1] <- as.numeric(p2[1]) * cos(etheta) - as.numeric(p2[2]) * sin(etheta)
    output[,2] <- as.numeric(p2[1]) * sin(etheta) + as.numeric(p2[2]) * cos(etheta)
  }else{
    output[,1] <- p2[1] * cos(etheta) - p2[2] * sin(etheta)
    output[,2] <- p2[1] * sin(etheta) + p2[2] * cos(etheta)
  }
  return(output)
}

## 点の平行移動
# pは(x,y)のデータフレーム、またはベクトル
  # 各行が1データ
# (alpha,beta)の並行移動（それぞれベクトル or 値）
# 平行移動の値にベクトルを入れると、pの各行と対応する
#   その場合はalpha, betaの長さと、pの行数を揃える
# 出力はデータフレーム
point.translate <- function(p,alpha,beta){
  if(length(alpha) != length(beta)){
    stop("length of alpha and beta should be same")
  }else{
    if (is.matrix(p)) {
      stop("p must be vector or data frame")
    }
    p <- data.frame(x = p[1], y = p[2])
    q <- data.frame(alpha = alpha,beta = beta)
    if(nrow(p) > nrow(q)){
      q <- as.data.frame(mapply(rep,q,nrow(p)))
    }else if(nrow(p) < length(alpha)){
      p <- as.data.frame(mapply(rep,p,nrow(q)))
    }
    p <- matrix(as.matrix(p),nrow(p),ncol(p))
    q <- matrix(as.matrix(q),nrow(q),ncol(q)) 

    output <- createEmptyDf(nrow(p),2,c("x","y"))
    output$x <- p[,1] + q[,1]
    output$y <- p[,2] + q[,2]
    # output <- p + q
    return(output)
  }
}

## 2点間の距離を求める
# 2点x, yの間の距離を算出する
# p, qはベクトルまたはデータフレーム
distance.points <- function(p,q){
  if(is.vector(p)){
    output <- sqrt((q[1] - p[1])^2 + (q[2] - p[2])^2)
    return(as.numeric(output))
  }else{
    output <- sqrt((q[,1] - p[,1])^2 + (q[,2] - p[,2])^2)
    return(as.vector(output))
  }
  
}

## 点pを通り角度がphiの直線の傾きbと切片a
# pはデータフレーム（複数点）かベクトル（1点）
point.line <- function(p, phi){
  if(!(is.data.frame(p) | (is.vector(p) & length(p) == 2))){
    stop("p must be data frame (multi points) or vector (single point)")
  }
  output <- createEmptyDf(length(phi),2,c("a","b"))
  
  output$b <- tan(phi)
  if(is.vector(p) | nrow(as.data.frame(p)) == 1){
    output[,1] <- as.numeric(p[2]) - as.numeric(p[1]) * output$b
  }else{
    output[,1] <- p[2] - p[1] * output$b
  }

  return(output)
}

## あらゆる角度を0-2piの範囲にで表記する
# 入力は値またはベクトル。データフレームの列も可
zero.to.2pi <- function(theta){
  # データフレーム化
  input <- createEmptyDf(length(theta),2,c("theta","is.minus"))
  input[,1] <- theta
  # 負の値判定
  input$is.minus <- input$theta < 0
  # 0から2piの範囲に収める
  output <- abs(input$theta) %% (2 * pi)
  # もともと負だった値は2piから除算
  output[input$is.minus] <- 2 * pi - output[input$is.minus] 

  return(output)
}

## あらゆる角度を-pi-piの範囲で表記する
# 入力は値またはベクトル。データフレームの列も可
mpi.to.pi <- function(theta){
  # データフレーム化
  input <- createEmptyDf(length(theta),2,c("theta","is.minus"))
  input[,1] <- theta
  # 負の値判定
  input$is.minus <- input$theta < 0
  # 0から2piの範囲に収める
  output <- abs(input$theta) %% (2 * pi)
  # もともと負だった値は2piから除算
  output[input$is.minus] <- 2 * pi - output[input$is.minus] 
  # pi~2piの範囲にあるものを-pi~0にする
  output[output > pi] <- output[output > pi] - 2 * pi
  
  return(output)
}

# 数学的操作（応用） -----------------------------------------------------------

## 直線と楕円が交わるかの判定
# 直線と楕円の方程式（に必要な変数）を与えて、交わるかどうか判定。
# 値は、単一の値もしくはベクトルに対応する
# 単純に交差するのでなく、点pcから、lphi方向に伸びる片線分と交差することを判定する
ellipse.line.cross <- function(pcx,pcy,lphi,ealpha,ebeta,ea,eb,etheta){
  # 片線分方向に存在する灌木を判定
  if(lphi > pi/2){
    aniso.bool <- ealpha < pcx & ebeta > pcy
  }else if(lphi < -pi/2){
    aniso.bool <- ealpha < pcx & ebeta < pcy
  }else if(lphi == pi/2){
    aniso.bool <- ebeta > pcy
  }else if(lphi == -pi/2){
    aniso.bool <- ebeta < pcy
  }else if(lphi > 0){
    aniso.bool <- ealpha > pcx & ebeta > pcy
  }else {
    aniso.bool <- ealpha > pcx & ebeta < pcy
  }

  pc <- c(pcx, pcy)
  # 楕円中心を原点にして、-etheta回転した座標系を考える
  pc2 <- as.data.frame(point.rotate(point.translate(pc,-ealpha, -ebeta),-etheta))

  lphi2 <- lphi - etheta
  ab <- point.line(pc2, lphi2)
  q <- as.vector(ab[,1])
  p <- as.vector(ab[,2])
  
  # 楕円と直線の連立方程式について、判別式Dを考える。
  D <- ea^2 * p^2 + eb^2 - q^2
  cross.bool <- D >= 0
  output <- aniso.bool & cross.bool
  return(output)
}

## 直線の楕円の交点の算出
# 直線はpcを通り、傾きtan(lphi)
# 1本の直線に対して複数の楕円との交点を考える
# 交点のうちPCから近い方がx1, y1、遠いほうがx2, y2
ellipse.line.cross.point <- function(pc, lphi, sh.data){
  # sh.data <- sh.data[line.sh.cross,]
  # 情報取得
  alpha <- sh.data$alpha
  beta <- sh.data$beta
  a <- sh.data$a
  b <- sh.data$b
  theta <- sh.data$theta
  
  # 回転後の直線
  pc <- data.frame(x = pc[1], y = pc[2])
  pc2 <- point.rotate(point.translate(pc,-alpha, -beta),-theta)
  lphi2 <- lphi - theta
  # 直線のパラメータ
  # ab <- point.line(pc2, lphi2)
  # q <- as.vector(ab[,1])
  # p <- as.vector(ab[,2])
  
  p <- tan(lphi2)
  q <- pc2$y - pc2$x * p
  
  
  # 原点中心、無回転の楕円と直線の交点のx座標は
  p.l <- (-p * q * a^2 + sqrt((a * b)^2 * ((a * p)^2 - q^2 + b^2)))/((a * p)^2 + b^2)
  p.s <- (-p * q * a^2 - sqrt((a * b)^2 * ((a * p)^2 - q^2 + b^2)))/((a * p)^2 + b^2)
  
  # y座標を加える
  p.l <- as.data.frame(cbind(p.l, tan(lphi2) * (p.l - pc2[1]) + pc2[2]))
  p.s <- as.data.frame(cbind(p.s, tan(lphi2) * (p.s - pc2[1]) + pc2[2]))
  
  # もとの座標軸に戻す
  p.l2 <- point.translate(point.rotate(p.l,theta),alpha,beta)
  p.s2 <- point.translate(point.rotate(p.s,theta),alpha,beta)
  
  # PCから近い順に並べる
  if(lphi <= -pi/2 | pi/2 <= lphi ){
    output <- data.frame(cbind(p.l2, p.s2))
  }else{
    output <- data.frame(cbind(p.s2, p.l2))
  }
  colnames(output) <- c("x1","y1","x2","y2")
  
  # 出力
  return(output)
  
}

## 与えられた点Pが、任意の楕円内に存在するか判定
# pは(x,y)のベクトル（行ベクトルで良い）もしくはデータフレーム
#   各行が1データ
#   pもしくは灌木のデータが一つのときは一つのデータに対して、もう一方をすべて考える
#   それぞれ複数の場合は各行を1データと考える
# 点Pを(-alpha, -beta)平行移動、-theta回転移動する→P'
# P'が長短軸（a,b）、原点中心の楕円内にあるか判定

point.in.ellipse <- function(p,ealpha,ebeta,ea,eb,etheta){
  if(length(ealpha) != length(ebeta)){
    stop("length of alpha and beta should be same")
  }else{
    p <- data.frame(x = p[1], y = p[2])
    p2 <- point.rotate(point.translate(p,-ealpha, -ebeta),-etheta)
    p2 <- matrix(as.matrix(p2),nrow(p2),ncol(p2))
    if(length(ealpha)==1 ){ # 灌木の値が1つのみ(灌木, p両方1つを含む)
      output <- p2^2 %*% (1/c(ea,eb))^2 <= 1
      output <- as.vector(output)
    }else if(nrow(p)==1){ #灌木の値が複数あって、pが一つ→どれか一つの中にあれば良い
      output <- p2^2 %*% t((1/cbind(ea,eb))^2) <= 1
      diag(output)
      output <- sum(diag(output)) > 0
    }else if(length(p[,1]) == length(ealpha)){ #灌木の値がpと同じ数ある（それぞれ対応）
      output <- rowSums(p2^2 * (1/cbind(ea,eb))^2) <= 1
      output <- as.vector(output)
    }else{
      print("error: point.in.ellipse")
      print(p)
    }
    return(output)
  }
}

## 特定の点について、特定の楕円体におけるz座標（灌木高さに相当）を算出
# pは(x,y)のベクトル（行ベクトルで良い）もしくは行列・データフレーム
#   各行が1データ
#   点pと灌木の数は対応している必要がある(片方が一つ、もう片方が複数には非対応)
cul.z.ellipse <- function(p,ealpha,ebeta,ea,eb,ec,etheta){
  p <- data.frame(x = p[1], y = p[2])
  B = point.rotate(point.translate(p,-ealpha,-ebeta),-etheta)
  ab <- cbind(1/ea,1/eb)
  
  if(length(p[,1]) == length(ealpha)){ #灌木の値がpと同じ数ある（それぞれ対応）
    z = ec * sqrt(1-rowSums(ab^2 * B^2))
  }else{
    print("error: cul.z.ellipse need same length data in point and ellipse")
  }
  return(z)
}

## ある直線上の楕円体における最高点を算出
# ある直線によって切断された楕円体における高さを算出
# 前提条件として、楕円体中心が範囲内に存在する（acent）、楕円体が直線と交点を持つ（acrss）の判定結果が
# 灌木のデータとして与えられていることが必要
# 必要データは灌木データ（データフレーム）と直線データ（値（座標）およびベクトル（角度）一本分）

max.z.ellipse.line <- function(sh.data, pcx, pcy,ang){
  
  pc <- c(pcx, pcy)
  # 直線の回転
  pc2 <- point.rotate(point.translate(pc,-sh.data$alpha, -sh.data$beta),-sh.data$theta)
  
  # パラメータ取得
  a <- sh.data$a
  b <- sh.data$b
  c <- sh.data$c

  p1 <- tan(ang[1] - sh.data$theta)
  p2 <- tan(ang[2] - sh.data$theta)
  q1 <- pc2[,2] - pc2[,1] * p1
  q2 <- pc2[,2] - pc2[,1] * p2
  
  # 直線と交わるものだけ抽出
  bool1 <- sh.data$acrss == 1 & !sh.data$acent == 1
  bool2 <- sh.data$acrss == 2 & !sh.data$acent == 1
  a1 <- a[bool1]
  b1 <- b[bool1]
  c1 <- c[bool1]
  p1 <- p1[bool1]
  q1 <- q1[bool1]
  a2 <- a[bool2]
  b2 <- b[bool2]
  c2 <- c[bool2]
  p2 <- p2[bool2]
  q2 <- q2[bool2]
  
  # 結果格納データフレーム作成
  z <- createEmptyDf(nrow(sh.data),ncol = 4,colnames = c("l1","l2","sh.h","result"))
  
  # それぞれのパターンのときの高さ算出
  z$l1[bool1] <- c1 * sqrt(1 - (q1)^2 / (a1^2 * p1^2 + b1^2))
  z$l2[bool2] <- c2 * sqrt(1 - (q2)^2 / (a2^2 * p2^2 + b2^2))
  z$sh.h <- c
  
  # 実際の値抽出
  z$result[bool1] <- z$l1[bool1]
  z$result[bool2] <- z$l2[bool2]
  z$result[sh.data$acent == 1] <- z$sh.h[sh.data$acent == 1]
  
  return(z$result)
}

## 特定の範囲に収まる直線lの端点座標取得
# aは切片、bは傾き
# 定義域（x1,x2）、値域（y1,y2）（デフォルトは両方(0,20))
# 端点の座標のデータフレーム
# x座標がより小さい方が上の行にある
# 特定の範囲に直線が交差しない場合は2×2の行列にNAが入ったものを返す

length.line.in.range <- function(a,b,x = c(0,20),y = c(0,20)){
  output <- createEmptyDf(2,2,c("x","y"))
  # サイト境界線x = x1, x = x2, y = y1, y = y2　それぞれと直線lの交点（のy座標、x座標）を算出
  intercept <- a + b * x # y座標
  value <- (y - a) / b # x座標
  
  # x1 <= value <= x2および y1 <= intercept <= y2を満たすかどうか
  logi.intercept <- y[1] <= intercept & intercept <= y[2]
  logi.value <- x[1] <= value & value <= x[2]
  
  if(sum(logi.intercept) == 0 & sum(logi.value) == 0){
    output$x <- c(NA,NA)
    output$y <- c(NA,NA)
  }else if(sum(logi.intercept) == 0){
    output$x <- value
    output$y <- y
  }else if(sum(logi.intercept) == 1){
    output$x <- c(x[logi.intercept],value[logi.value])
    output$y <- c(intercept[logi.intercept],y[logi.value])
  }else if (sum(logi.intercept) == 2){
    output$x <- intercept
    output$y <- x
  }
  output <- output[order(output$y),]
  output <- output[order(output$x),]
  return(output)
}

## ある楕円と、円とが交点を持つかを近似的に求める
# 円のデータ(cx,cy,cr)と楕円のデータ(ealpha,ebeta,ea,eb,etheta)
# それぞれのデータは必ず一つの値
ellipse.circle.cross <- function(cx,cy,cr,ealpha,ebeta,ea,eb,etheta,byang=3600){
  
  i_phi <- seq(-pi,pi, by = 2 * pi/byang)
  
  # 円の媒介変数表示
  c.coord <- as.data.frame(cbind(r * cos(i_phi) + cx, r * sin(i_phi) + cy))
  # 円を構成する各点が楕円内に存在するか判定
  c.inout <- point.in.ellipse(c.coord,ealpha,ebeta,ea,eb,etheta)
  
  if(sum(c.inout) == 0){
    output = FALSE
  }else{
    output = TRUE
  }
  
  return(output)
}



## 任意の角度範囲phi1 ~ phi2の中に、点pが存在するかどうか
# phi1, phi2の大小は問わないが2piの範囲において、phi1からphi2までの範囲を考える。
# 引数は、phi1, ph2と点pの極座標表示における角度theta
# つまり、方角において、ある範囲にその方角が含まれるかどうかを判定する。
# 入力はベクトルまたは値。すべて同じ列か、thetaもしくは（phi1, phi2のセット）が1つで逆が多数か
angle.range.in <- function(theta, phi1, phi2){
  # すべての角度を0-2piの範囲に収める
  theta <- zero.to.2pi(theta)
  phi1 <- zero.to.2pi(phi1)
  phi2 <- zero.to.2pi(phi2)
  
  # データフレーム化
  input <- data.frame(theta = theta, phi1 = phi1, phi2 = phi2)
  
  # phi1、phi2のどちらが大きいか判定
  input$is.range.large <- input$phi1 <= input$phi2 
  
  # phi1 ~ phi2 の範囲もしくはphi2 ~ ph1の範囲にthetaがあるか
  input$onetotwo <-  input$phi1 <= input$theta & input$theta <= input$phi2
  input$twotoone <-  !(input$phi2 <= input$theta & input$theta <= input$phi1)
  
  # phi1とphi2の大小によって、どちらの範囲を使うか
  output <-input$onetotwo
  output[!input$is.range.large] <- input$twotoone[!input$is.range.large]

  return(output)
}

## ある点が2直線（方向あり、つまりベクトル）に囲まれる領域に存在するか判定
# 境界は含む
# 点はベクトルpで与えられる。複数の点の場合はデータフレーム
  # 入力は、p複数と1セットの直線、もしくはpとそれに対応する2直線。
  # 単独点と複数セットの直線には非対応
# 2直線は同じ点(pcx, pcy)を通り、角度lphi1, lphi2（-pi ~ pi, lphi1 < lphi2）方向に伸びる直線（片線分）
# 直線には向きがあるので、2直線で囲われる領域は一意に定まる
point.line.in <- function(p, pcx, pcy, lphi1, lphi2){
  if(length(lphi1) != length(lphi2)){
    stop("ERROR: diffferent length of phi of line 1 and line 2")
  }else{
    if (length(lphi1) != 1) {
      if(nrow(p) != length(lphi1)){
        stop("ERROR: diffferent length of point and line")
      }
    }
    # PCの座標を原点になるようにpを平行移動
    p2 <- point.translate(p,-pcx,-pcy)
  
    # データフレーム化 
    input <- cbind(p2,pcx,pcy,lphi1, lphi2)
    colnames(input) <- c("px","py","pcx", "pcy", "lphi1", "lphi2")

    # 極座標変換
    input$pr <- sqrt(input$px^2 + input$py^2)
    input$ptheta <- atan2(input$py, input$px)
    
    # 何周してでも、lphi1とlphi2の間にあれば良い
    output <- angle.range.in(input$ptheta, lphi1, lphi2)
    
    # output <- (lphi1 <= input$ptheta & input$ptheta <= lphi2 )| 
    #           (lphi1 <= input$ptheta + 2 * pi & input$ptheta + 2 * pi <= lphi2 ) | 
    #           (lphi1 <= input$ptheta - 2 * pi & input$ptheta - 2 * pi <= lphi2)
  }
  return(output)
}



