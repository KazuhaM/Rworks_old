
# Hea ---------------------------------------------------------------------
### テスト用データ
i_ang <- 1
shrub.data <- temp.WsiteD.d.range
pc <- c(PCx,PCy)
# lphi <- ang.range[i_ang]
ldist = r

lphi <- 110 * pi / 180

points(l_hi$lp_x,l_hi$lp_y,col = gray( 1-Haei/max(Haei)),pch=16)

p <- data[,c("lp_x","lp_y")]
ealpha <- data$alpha
ebeta <- data$beta
ea <- data$a
eb <- data$b
ec <-data$c
# etheta <- data$theta
etheta <- lphi

plot(l_hi[,c("lp_x","lp_y")],xlim = c(-2,22),ylim = c(-2,22),col=gray(1-Haei/max(Haei)))
abline(pcy-pcx*tan(lphi), tan(lphi))
# points(data[,c("lp_x","lp_y")],col=gray(1-z/0.4),pch = 16,cex = 1.2)
points(data$alpha,data$beta,pch = 16,cex = data$a,col = 2)




# point.in.ellipse --------------------------------------------------------

p <- data[,c("lp_x","lp_y")]
ealpha <- sh.data$alpha
ebeta <- sh.data$beta
ea <- sh.data$a
eb <- sh.data$b
etheta <- sh.data$theta


# round.robin.data --------------------------------------------------------

data1 <- l
data2 <- shrub.data

# point.line.in -----------------------------------------------------------

  p <- as.data.frame(cbind(rnorm(100,10,10),rnorm(100,10,10)))

  p <- p[p[,1]>=0 & p[,1]<=20,]
  p <- p[p[,2]>=0 & p[,2]<=20,]
  row.names(p) = NULL

  pcx = 15.3
  pcy = 2.4
  i_wd <- wdlev[30]
  temp.range <- c(i_wd - i_rangang/2, i_wd + i_rangang/2)

  lphi1 <- temp.range[1]
  lphi2 <- temp.range[2]
  test.p <- point.line.in(p,pcx,pcy,lphi1, lphi2)
  tets.p.col <- rep(1,length(test.p))
  tets.p.col[test.p] <- 2
  plot(p,col=tets.p.col)
  abline(pcy - tan(lphi1) * pcx, tan(lphi1))
  abline(pcy - tan(lphi2) * pcx, tan(lphi2),col =3)

# temp.WsiteD.a.range -----------------------------------------------------

plot(PCx,PCy,xlim = c(-2,22),ylim = c(-2,22))
abline(h = 0,lty = 2)
abline(h = 20,lty = 2)
abline(v = 0,lty = 2)
abline(v = 20,lty = 2)

temp.range <- c(i_wd - i_rangang/2, i_wd + i_rangang/2)

lphi1 <- temp.range[1]
lphi2 <- temp.range[2]
abline(PCy - tan(lphi1) * PCx, tan(lphi1))
abline(PCy - tan(lphi2) * PCx, tan(lphi2),col =3)

test.p <- point.line.in(p,pcx,pcy,lphi1, lphi2)
tets.p.col <- rep(1,nrow(temp.WsiteD.d.range))
tets.p.col[sh.angle.center] <- 2 
tets.p.col[sh.angle.cross] <- 4 

points(temp.WsiteD.d.range[,c("alpha","beta")],col = tets.p.col,pch = 16,cex=temp.WsiteD.d.range$a*5)


  sh.angle.center <- point.line.in(temp.WsiteD.d.range[,c("alpha","beta")],
                                   PCx,PCy,temp.range[1], temp.range[2])
  
  # 境界線と灌木が交点を持つ。
  sh.angle.cross1 <- ellipse.line.cross(PCx,PCy,
                                        temp.range[1], 
                                        temp.WsiteD.d.range$alpha,
                                        temp.WsiteD.d.range$beta,
                                        temp.WsiteD.d.range$a,
                                        temp.WsiteD.d.range$b,
                                        temp.WsiteD.d.range$theta)
  sh.angle.cross2 <- ellipse.line.cross(PCx,PCy,
                                        temp.range[2], 
                                        temp.WsiteD.d.range$alpha,
                                        temp.WsiteD.d.range$beta,
                                        temp.WsiteD.d.range$a,
                                        temp.WsiteD.d.range$b,
                                        temp.WsiteD.d.range$theta)
  # l1, l2どちらかと交点を持てば良い
  sh.angle.cross <- sh.angle.cross1 | sh.angle.cross2
  ## 範囲内に中心がある or 境界線と灌木が交点を持つ灌木を抽出
  temp.WsiteD.a.range <- temp.WsiteD.d.range[sh.angle.center | sh.angle.cross,]
  
# max.z.ellipse.line ------------------------------------------------------

sh.data = temp.WsiteD.a.range
pcx <- PCx
pcy <- PCy  
ang <- temp.range
  
max.z.ellipse.line(temp.WsiteD.a.range,PCx, PCy, temp.range)

# Hd -----------------------------------------------------------------------

sh.data <- temp.WsiteD.a.range
pcx <- PCx
pcy <- PCy
ang <-temp.range



plot(pcx, pcy,xlim = c(-2,22),ylim = c(-2,22),col=2)
points(sh.data[,c("alpha","beta")])
text(sh.data$alpha, sh.data$beta,row.names(sh.data))
seplinef <- seq(0,20, by = 1)
seplineb <- seq(0,20, by = 5)
for(i in seplinef ){
  abline(h = i, lty = 3)
  abline(v = i, lty = 3)
}
for(i in seplineb ){
  abline(h = i, lty = 2)
  abline(v = i, lty = 2)
}
points(temp.WsiteD.a.range[,c("alpha","beta")],col = temp.WsiteD.a.range$acrss+1,pch=16+temp.WsiteD.a.range$acent)
abline(pcy - tan(temp.range[1]) * pcx, tan(temp.range[1]),col =2)
abline(pcy - tan(temp.range[2]) * pcx, tan(temp.range[2]),col =3)

sh.d

distance.points(c(pcx, pcy),sh.data[,c("alpha","beta")])
# range.area.monte.carl ---------------------------------------------------



range.area.monte.carl(i_dist, c(PCx, PCy), temp.range)

plot(pcx, pcy,xlim = c(-2,22),ylim = c(-2,22),col=2)
abline(PCy - tan(temp.range[1]) * PCx, tan(temp.range[1]))
abline(PCy - tan(temp.range[2]) * PCx, tan(temp.range[2]),col =3)

points(sh.data[,c("alpha","beta")])
text(sh.data$alpha, sh.data$beta,row.names(sh.d))
seplinef <- seq(0,20, by = 1)
seplineb <- seq(0,20, by = 5)
for(i in seplinef ){
  abline(h = i, lty = 3)
  abline(v = i, lty = 3)
}
for(i in seplineb ){
  abline(h = i, lty = 2)
  abline(v = i, lty = 2)
}
abline(h = 20,lwd = 2)
abline(h = 0,lwd = 2)
abline(v = 20,lwd = 2)
abline(v = 0,lwd = 2)





# street'
i_ang = 30
sh.data <- temp.WsiteD.d.range
pc <- c(PCx,PCy)
lphi <- ang.range[i_ang]
lphi <- 70 * pi / 180


plot(pc[1],pc[2],xlim = c(-2,22),ylim = c(-2,22),col=2)
abline(pc[2] - pc[1] * tan(lphi), tan(lphi))
# points(line.range2[1],line.range2[2],col=2)
# points(l.end.p1,col=3,pch = 16)
# points(l.end.p2,col=3,pch = 17)

points(sh.data$alpha, sh.data$beta, pch = 18, col = 4)
text(sh.data$alpha, sh.data$beta,row.names(sh.data), pch = 18, col = 4)
# points(data.in$alpha, data.in$beta, pch = 18, col = 2)

seplinef <- seq(0,20, by = 1)
seplineb <- seq(0,20, by = 5)
for(i in seplinef ){
  abline(h = i, lty = 3)
  abline(v = i, lty = 3)
}
for(i in seplineb ){
  abline(h = i, lty = 2)
  abline(v = i, lty = 2)
}
abline(h = 20,lwd = 2)
abline(h = 0,lwd = 2)
abline(v = 20,lwd = 2)
abline(v = 0,lwd = 2)

points(l_hi$lp_x,l_hi$lp_y,col = gray( 1-Haei/max(Haei)),pch=16)

windows()
plot(lineIndicator$wd * 180 / pi, lineIndicator$Hae,pch = 16,xlim = c(65,180))
par(new =  T)
plot(lineIndicator$wd * 180 / pi, lineIndicator$street_dist,col= 2,pch = 17,xlim = c(65,180),ylim = c(0,50))
par(new =  T)
plot(lineIndicator$wd * 180 / pi, lineIndicator$street, col = 3,pch = 17,xlim = c(65,180),ylim = c(0,50))
abline(v = 0)
abline(v = 45)
abline(v = -90,col = 2)
abline(v = 135)
abline(v = 70,col = 2)

#length.line.in.range
a <- pc[2] - pc[1] * tan(lphi)
b <- tan(lphi)

# ellipse.line.cross.point
sh.data <- data.in

# line.point
phi <- lphi2
p <-pc2

# ellipse.line.cross
sh.data = temp.WsiteD.d.range
pcx <- PCx 
pcy <- PCy
ealpha <- sh.data$alpha
ebeta <- sh.data$beta
ea <- sh.data$a
eb <- sh.data$b
etheta <- sh.data$theta
lphi <- temp.range[2]

sh.data[output,]

# lphi2 <- lphi - etheta

plot(pcx,pcy,xlim = c(-2,22),ylim = c(-2,22),col=3,pch = 16)
abline(point.line(c(pcx, pcy), lphi)[1,1],point.line(c(pcx, pcy), lphi)[1,2])

points(sh.data$alpha, sh.data$beta, pch = 18, col = 4)
points(sh.data[output,]$alpha, sh.data[output,]$beta, pch = 18, col = 2)
segments()

s <- point.translate(data.frame(t(pc)),-ealpha, -ebeta)
t <- point.rotate(point.translate(pc,-ealpha, -ebeta),-etheta)
s <- as.data.frame(s)
t <- as.data.frame(t)


plot(pc[1],pc[2],xlim = c(-22,22),ylim = c(-22,22),pch = 16,col = 1)
text(ealpha, ebeta,round(etheta*180/pi,0),col = 2,pch= 16)
abline(h = 20,lwd = 2)
abline(h = 0,lwd = 2)
abline(v = 20,lwd = 2)
abline(v = 0,lwd = 2)
points(s[,1],s[,2],pch = 16,col = 3)
arrows(ealpha, ebeta,s[,1],s[,2],col = 3)
points(t[,1],t[,2],pch = 16,col = 4)
arrows(s[,1],s[,2],t[,1],t[,2],col = 4)
la <- point.line(t, lphi2)[1]
lb <- point.line(t, lphi2)[2]
for(i in 1:nrow(la)){
  abline(as.numeric(la[i,1]),as.numeric(lb[i,1]),col = 2)
}

abline(-1.943833,-0.3443276,col=2)


# ellipse.line.cross.point
sh.data <- data.in
p <- point.translate(pc,-ealpha, -ebeta)
etheta <- -etheta

##
p = data.frame(t(pc))
q <- data.frame(alpha = -ealpha,beta = -ebeta)
point.translate(p, -ealpha, -ebeta)
alpha = -ealpha
beta = -ebeta
p + q


point.rotate(p, etheta)


## ellipse.circle.cross

cx <- PCx
cy <- PCy
cr<- r
ealpha <- temp.WsiteD$alpha[i_shrub]
ebeta <- temp.WsiteD$beta[i_shrub]
ea <- temp.WsiteD$a[i_shrub]
eb <- temp.WsiteD$b[i_shrub]
etheta <- temp.WsiteD$theta[i_shrub]

p <-c.coord





# result.i.r.ang ------------------------------------------------------------------
result.i.r.ang

result.available <- result.i.r.ang[result$us >= ust,] # 臨界摩擦速度で切る
result.available.l <- result.available[result.available$Arate_line >=0.95,] # line指標の有効データ率95%以上
result.available.r <- result.available[result.available$S_range /
                                         result.available$maxS_range >=0.60,] # range指標の有効データ率95%以上
# colnames(result)
# lineIndicators
us.l <- result.available.l$us
plot(sf~Hae, data = result.available.l,xlim=c(200,250),col=gray(1-(us.l-ust)/max(us.l-ust)),pch = 16)
plot(sf~street_dist, data = result.available.l,col=gray(1-(us.l-ust)/max(us.l-ust)),pch = 16)
plot(sf~street, data = result.available.l,col=gray(1-(us.l-ust)/max(us.l-ust)),pch = 16)

# rangeIndicators
us.r <- result.available.r$us
plot(sf~Hd, data = result.available.r,col=gray(1-(us.r-ust)/max(us.r-ust)),pch = 16)
plot(sf~lambda_dist, data = result.available.r,col=gray(1-(us.r-ust)/max(us.r-ust)),pch = 16)
plot(sf~lambda, data = result.available.r,col=gray(1-(us.r-ust)/max(us.r-ust)),pch = 16)


# plot final.result -------------------------------------------------------
path <- "D:/OneDrive - g.ecc.u-tokyo.ac.jp/LEP/2020/00working/1301MongoliaAnalysis8/EachPC_EachTime/Data/result"
setwd(path)

library("RColorBrewer")
data <- read.csv("various_indicator.csv")
# data <- read.csv("100various_indicator.csv")

lrate <- 0.95
rrate <- 0.6

marker <- c(0,1,2,5,6,7,15,16,17,18)

# データ整形
pcids <- paste(data$site, data$ev, data$pcNo,sep="_")
data$pcid <- which(levels(as.factor(pcids))== pcids)

### 角度範囲および距離範囲調整
i_ang <- 5
i_dst <- 5
rngang <-levels(as.factor(data$rangang))
rngdst <-levels(as.factor(data$rangdist))

data2 <- data[data$rangang == rngang[i_ang] & data$rangdist == rngdst[i_dst],]

## 臨界摩擦速度で切る
  data.available <- data2[data2$us >= ust,] # 臨界摩擦速度で切る
  data.available <- data.available[!is.na(data.available$street_dist),]
  data.available.l <- data.available[data.available$Arate_line >=lrate,] # line指標の有効データ率
  data.available.r <- data.available[data.available$S_range /
                                       data.available$maxS_range >=rrate,] # range指標の有効データ率
  
  ## lineIndicators
  us.l <- data.available.l$us
  par(mar = c(8,4,4,6))
  # Hae
  plot(sf~Hae, data = data.available.l,
       col=1,
       pch = 16,
       cex.lab = 1.2, cex.axis = 1.0, 
       main = paste("line indicators ang: ",rngang[i_ang],"distance: ",rngdst[i_dst],sep = ""))
    par(xpd=T)# 凡例を表示
    legend(par()$usr[2], par()$usr[4],levels(as.factor(data.available.l$pcid)),pch = marker, legend="凡例")
    par(xpd=F)
  
  # street_dist
  par(new = T)
  plot(sf~street_dist, data = data.available.l,
       col=2,
       pch = 17,
       xlim = c(0,max(max(data.available.l$street_dist,rm.na = T),max(data.available.l$street))),
       cex.lab = 1.2, cex.axis = 1.0, main = "",axes = FALSE)
    par(xpd=T)# 凡例を表示
    axis(1, xlim = c(0, max(data.available.l$street_dist)), line = 4, col = "red")   # left 2nd y
    mtext("street_dist",side = 1, line = 5)     
    par(xpd=F)
    
  # street
  par(new = T)
  plot(sf~street, data = data.available.l,
       col=3,
       pch = 18,
       xlim = c(0,max(max(data.available.l$street_dist),max(data.available.l$street))),
       cex.lab = 1.2, cex.axis = 1.0, main = "",axes = FALSE)
    # par(xpd=T)# 凡例を表示
    # axis(3, xlim = c(0, max(data.available.l$street_dist)), line = 1, col = "blue")   # left 2nd y
    # mtext("street",side = 3, line = 3)   
  
  legend(par()$usr[2], par()$usr[3],c("Hae","street'","street"),ncol = 1,pch =1,col = c("black","red","blue"), legend="凡例")
    
  # rangeIndicators
  us.r <- data.available.r$us
  par(mar = c(5,4,4,6))
  
  # Hd
  plot(sf~Hd, data = data.available.r,
       col=adjustcolor("black", alpha=(us.r-ust)/max(us.r-ust)),
       pch = marker[data.available.r$pcid],
       cex.lab = 1.2, cex.axis = 1.0, 
       main = paste("line indicators ang: ",rngang[i_ang],"distance: ",rngdst[i_dst],sep = ""))
  par(xpd=T)# 凡例を表示
  legend(par()$usr[2], par()$usr[4],levels(as.factor(data.available.r$pcid)),pch = marker, legend="凡例")
  par(xpd=F)
  
  # lambda_dist
  par(new = T)
  plot(sf~lambda_dist, data = data.available.r,
       col=adjustcolor("red", alpha=(us.r-ust)/max(us.r-ust)),
       pch = marker[data.available.r$pcid],
       xlim = c(0,max(max(data.available.l$street_dist),max(data.available.l$street))),
       cex.lab = 1.2, cex.axis = 1.0, main = "",axes = FALSE)
  par(xpd=T)# 凡例を表示
  axis(1, xlim = c(0, max(data.available.r$street_dist)), line = 4, col = "red")   # left 2nd y
  mtext("street_dist",side = 1, line = 5)     
  par(xpd=F)
  
  # lambda
  par(new = T)
  plot(sf~lambda, data = data.available.r,
       col=adjustcolor("blue", alpha=(us.r-ust)/max(us.r-ust)),
       pch = marker[data.available.r$pcid],
       xlim = c(0,max(max(data.available.l$street_dist),max(data.available.l$street))),
       cex.lab = 1.2, cex.axis = 1.0, main = "",axes = FALSE)
  # par(xpd=T)# 凡例を表示
  # axis(3, xlim = c(0, max(data.available.r$street_dist)), line = 1, col = "red")   # left 2nd y
  # mtext("street",side = 3, line = 3)  
  
  legend(par()$usr[2], par()$usr[3],c("Hae","street'","street"),ncol = 1,pch =1,col = c("black","red","blue"), legend="凡例")
  
### sfが0より大きいとき
  data.upsf <- data2[data2$us >= ust,] # 臨界摩擦速度で切る
  data.upsf.l <- data.upsf[data.upsf$Arate_line >=lrate,] # line指標の有効データ率
  data.upsf.r <- data.upsf[data.upsf$S_range /
                                       data.upsf$maxS_range >=rrate,] # range指標の有効データ率
  
  ## lineIndicators
  us.l <- data.upsf.l$us
  par(mar = c(8,4,4,6))
  # Hae
  plot(sf~Hae, data = data.upsf.l,
       col=adjustcolor("black", alpha=(us.l-ust)/max(us.l-ust)),
       pch = marker[data.upsf.l$pcid],
       cex.lab = 1.2, cex.axis = 1.0, 
       main = paste("line indicators ang: ",rngang[i_ang],"distance: ",rngdst[i_dst],sep = ""))
  par(xpd=T)# 凡例を表示
  legend(par()$usr[2], par()$usr[4],levels(as.factor(data.upsf.l$pcid)),pch = marker, legend="凡例")
  par(xpd=F)
  
  # street_dist
  par(new = T)
  plot(sf~street_dist, data = data.upsf.l,
       col=adjustcolor("red", alpha=(us.l-ust)/max(us.l-ust)),
       pch = marker[data.upsf.l$pcid],
       xlim = c(0,max(max(data.upsf.l$street_dist),max(data.upsf.l$street))),
       cex.lab = 1.2, cex.axis = 1.0, main = "",axes = FALSE)
  par(xpd=T)# 凡例を表示
  axis(1, xlim = c(0, max(data.upsf.l$street_dist)), line = 4, col = "red")   # left 2nd y
  mtext("street_dist",side = 1, line = 5)     
  par(xpd=F)
  
  # street
  par(new = T)
  plot(sf~street, data = data.upsf.l,
       col=adjustcolor("blue", alpha=(us.l-ust)/max(us.l-ust)),
       pch = marker[data.upsf.l$pcid],
       xlim = c(0,max(max(data.upsf.l$street_dist),max(data.upsf.l$street))),
       cex.lab = 1.2, cex.axis = 1.0, main = "",axes = FALSE)
  # par(xpd=T)# 凡例を表示
  # axis(3, xlim = c(0, max(data.upsf.l$street_dist)), line = 1, col = "blue")   # left 2nd y
  # mtext("street",side = 3, line = 3)   
  
  legend(par()$usr[2], par()$usr[3],c("Hae","street'","street"),ncol = 1,pch =1,col = c("black","red","blue"), legend="凡例")
  
  # rangeIndicators
  us.r <- data.upsf.r$us
  par(mar = c(5,4,4,6))
  
  # Hd
  plot(sf~Hd, data = data.upsf.r,
       col=adjustcolor("black", alpha=(us.r-ust)/max(us.r-ust)),
       pch = marker[data.upsf.r$pcid],
       cex.lab = 1.2, cex.axis = 1.0, 
       main = paste("line indicators ang: ",rngang[i_ang],"distance: ",rngdst[i_dst],sep = ""))
  par(xpd=T)# 凡例を表示
  legend(par()$usr[2], par()$usr[4],levels(as.factor(data.upsf.r$pcid)),pch = marker, legend="凡例")
  par(xpd=F)
  
  # lambda_dist
  par(new = T)
  plot(sf~lambda_dist, data = data.upsf.r,
       col=adjustcolor("red", alpha=(us.r-ust)/max(us.r-ust)),
       pch = marker[data.upsf.r$pcid],
       xlim = c(0,max(max(data.upsf.l$street_dist),max(data.upsf.l$street))),
       cex.lab = 1.2, cex.axis = 1.0, main = "",axes = FALSE)
  par(xpd=T)# 凡例を表示
  axis(1, xlim = c(0, max(data.upsf.r$street_dist)), line = 4, col = "red")   # left 2nd y
  mtext("street_dist",side = 1, line = 5)     
  par(xpd=F)
  
  # lambda
  par(new = T)
  plot(sf~lambda, data = data.upsf.r,
       col=adjustcolor("blue", alpha=(us.r-ust)/max(us.r-ust)),
       pch = marker[data.upsf.r$pcid],
       xlim = c(0,max(max(data.upsf.l$street_dist),max(data.upsf.l$street))),
       cex.lab = 1.2, cex.axis = 1.0, main = "",axes = FALSE)
  # par(xpd=T)# 凡例を表示
  # axis(3, xlim = c(0, max(data.upsf.r$street_dist)), line = 1, col = "red")   # left 2nd y
  # mtext("street",side = 3, line = 3)  
  
  legend(par()$usr[2], par()$usr[3],c("Hae","street'","street"),ncol = 1,pch =1,col = c("black","red","blue"), legend="凡例")
  
  

# Okin model --------------------------------------------------------------
## eq4
  x.pred <- seq(0,50,by = 0.1)
  y.pred <- okin.eq4(x.pred, 1)
  plot(x.pred, y.pred,type = "l",ylim = c(0,1.1))
  text(0,y.pred[1],y.pred[1])
  abline(v = 10)
  text(10,y.pred[101],round(y.pred[101],2))
  
## eq5
  t.ust <- 0.65
  x.pred <- seq(0,1.5,by = 0.01)
  y.pred <- future_map2_dbl(x.pred,t.ust,okin.eq5)

  plot(x.pred, y.pred,type = "l")
  text(t.ust,0,t.ust)
  abline(v = t.ust)
  
### new model
  us <- temp.WusfD$Us[i_dat]
  pc <- c(PCx, PCy)
  lphi <- wd
  ldist <- r
  lambda <- temp.rng.Inds$lambda_dist
  shrub.data <- temp.WsiteD.a.range
  ustr <- ust
  
  tic()
  cul.model.new(lphi,us, pc,  ldist, lambda, shrub.data, ustr)
  toc()
  
  # 一定の範囲で全平均する
  wd.range.line <- seq(wd.range[1],wd.range[2],by = byang)
  formals(cul.model.new)$us <- us
  formals(cul.model.new)$pc <- c(PCx, PCy)
  formals(cul.model.new)$ldist <- r
  formals(cul.model.new)$lambda <- temp.rng.Inds$lambda_dist
  formals(cul.model.new)$shrub.data <- temp.WsiteD.a.range
  formals(cul.model.new)$ustr <- ust
  q_line <- future_map_dbl(wd.range.line,cul.model.new)
  mean(q_line,na.rm = T)
  
### Okin model 
  i_dat = 700
  aveh <- 0.3
  us <- 1.2
  pc <- c(PCx, PCy)
  lphi <- 2.4
  ldist <- r
  lambda <- temp.rng.Inds$lambda_dist
  shrub.data <- temp.WsiteD.a.range
  ustr <- ust
  
  cul.model.okin(lphi,us, pc,  ldist, lambda, aveh, shrub.data, ustr)

# data チェック ---------------------------------------------------------------
  path <- "D:/OneDrive - g.ecc.u-tokyo.ac.jp/LEP/2020/00working/1301MongoliaAnalysis8/EachPC_EachTime/Data/result"
  setwd(path)
  
  library("RColorBrewer")
  data <- read.csv("various_indicator.csv")
    # データ整形
  pcids <- paste(data$site, data$ev, data$pcNo,sep="_")
  index.sites <- levels(as.factor(pcids))
  each.same <- function(x,y){return(x == y)}
  formals(each.same)$y <- index.sites
  data$pcid <- unlist(lapply(lapply(pcids,each.same),which))
  data$pcid <- as.factor(data$pcid)
  
  ### 変数
  rngang <-levels(as.factor(data$rangang))
  rngdst <-levels(as.factor(data$rangdist))
  ind <- c("Hae","street_dist","street","Hd","lambda_dist","lambda")
  
  lrate <- 0.95
  rrate <- 0.9
  i_ang <- 5
  i_dst <- 5
  i_site <- 1
  i_ind <- 6
  index.sites[i_site]
  rngang[i_ang]
  as.numeric(rngdst[i_dst]) * 0.3
  marker <- c(0,1,2,5,6,7,15,16,17,18)
  ind[i_ind]
  
  {
    # W2-3のイベント5がus, ustがないので、一旦除外
    # data[data$ev != 5,c("Hae","street_dist","street","Hd","lambda_dist","lambda")]
    # 
    # # 中立条件でないとき（usがNAのとき）除外
    # data <- data[!is.na(data$us),]
    
    ### 角度範囲および距離範囲調整およびサイト-PC選定
    data2 <- data[data$rangang == rngang[i_ang] & data$rangdist == rngdst[i_dst],]
    data2 <- data2[data2$pcid == i_site,]
    
    
    data.available <- data2[data2$us >= data2$ust,] # 臨界摩擦速度で切る
    # その距離・角度範囲では、その風向に対してstreetが算出できない。
    # つまりその範囲がサイト範囲外であるとき
    # data.available <- data.available[!is.na(data.available$street_dist),]
    
    data.available.l <- data.available[data.available$Arate_line >=lrate,] # line指標の有効データ率
    data.available.r <- data.available[data.available$S_range /
                                         data.available$maxS_range >=rrate,] # range指標の有効データ率
    
    # 有効データ率で切ったとき
    if(i_ind >=4){
      eval(parse(text = paste("plot(data.available.r$wd * 180 / pi,data.available.r$",ind[i_ind],",
       xlim = c(-180,180),ylim=c(-1,max(data.available.r$",ind[i_ind],")))",sep= "")))
    }else{
      eval(parse(text = paste("plot(data.available.l$wd * 180 / pi,data.available.l$",ind[i_ind],",
       xlim = c(-180,180),ylim=c(-1,max(data.available.l$",ind[i_ind],")))",sep= "")))
    }
    
    # plot(data.available.l$wd * 180 / pi,data.available.l$Hae,
    #      xlim = c(-180,180),ylim=c(-1,max(data.available.l$Hae)))  
    points(data2$wd * 180 / pi, rep(-1, length(data2$wd)), col = "green") # 何もデータを切らないとき
    points(data.available$wd * 180 / pi, rep(-1, length(data.available$wd)), col = "red") # 臨界摩擦速度できったとき
    abline(v = 120)
    abline(v = 90)
    abline(v = 60)
    abline(v = 180)
  }
  max(data.available.l$wd * 180 / pi)
  plot(data2$wd,data2$Arate_line)
  
  plot(data$rangang,data$wd)

  wdpl <- read.csv("D:/OneDrive - g.ecc.u-tokyo.ac.jp/LEP/2020/00working/1301MongoliaAnalysis8/EachPC_EachTime/Data/Z0Us_MoM_60_sumdata.csv")
  plot(wdpl$mean3WD[wdpl$Event!=99])
  