
# library -----------------------------------------------------------------

library(sp)
library(tcltk2)
library(tictoc) # 処理時間計測
# library("fmsb")
library("RColorBrewer")
library(plotrix)
# 内外の判定 0 : 領域外の点 1 : 領域内の点 2 : 境界上の点(辺) 3 :境界上の点(頂点)
# res <- point.in.polygon(x, y, pol.x, pol.y)


# Cul erodibility -------------------------------------------------------------

tic()
path <- "D:/OneDrive - g.ecc.u-tokyo.ac.jp/LEP/2020/00working/1301MongoliaAnalysis8/ShrubDistribution"
setwd(path)

WsiteD <- read.csv("WsiteShrubDistribution.csv",header = T)
# site_name <- as.factor(WsiteD$Site)
# site_name <- levels(site_name)
max_h <- max(WsiteD$height[!is.na(WsiteD$height)])
min_h <- min(WsiteD$height[!is.na(WsiteD$height)])

# PC座標
WPCcoord <- read.csv("WsitePCDistribution.csv",header = T)

# 各サイトの始まりを取得
sites <- c("W2-3","W2-5","W3-3","W3-4")
initsite <- c()
for (i_row in 1:length(sites)) {
  initsite <- c(initsite,which(WPCcoord$SiteID == sites[i_row])[1])
}

# イベント風向(N0right)
eventwd <- c(245.6537782, # W2-3_4
             272.0940444, # W2-3_5
             63.42984944, # W2-3_6
             276.8279183, # W2-5_1
             291.2269448, # W3-3_1
             242.2881938) # W3-4_1
eventname <- c("W2-3_4","W2-3_5","W2-3_6","W2-5_1","W3-3_1","W3-4_1")
eventwd <- as.data.frame(eventwd)
eventwd$siteev <- eventname

# PCから風上に伸ばす直線のための変数
septime <- 1
sepcounts <- 1002

## 結果格納用データベースresult.shrb.distrに行を追加
result.shrb.distr <- data.frame(matrix(rep(NA,6), nrow=1))[numeric(0), ]
df.colnames <- c("site_ev","PC_No","shrubNo","d", "h", "h/d")
colnames(result.shrb.distr) <-df.colnames
pb <- txtProgressBar(min = 1, max = nrow(WPCcoord), style = 3)

for (i_pc in 1:nrow(WPCcoord)) {
  ### 準備
    # 一時結果用データフレーム
    temp.result <- data.frame(matrix(rep(NA,6), nrow=1))[numeric(0), ]
    colnames(temp.result) <-df.colnames
    
    # 該当サイト-イベント-PC のPCデータを抽出
    temp.pc <- WPCcoord[i_pc,] 
  if(temp.pc$Event != 99){
    
    # 該当サイト-イベントの灌木データを抽出
    temp_WsiteD <- WsiteD[WsiteD$Site == temp.pc$SiteID,]
    
    # イベント風向
    temp.siteev <- paste(temp.pc$SiteID,"_",temp.pc$Event,sep = "") # site event name
    sepangle <- eventwd$eventwd[which(eventwd$siteev == temp.siteev)[1]] # イベント風向取得

  
  ### 楕円ポリゴンの作成 
    shrb_px <- data.frame(matrix(rep(NA, pori_sm), nrow=1))[numeric(0), ]
    shrb_py <- data.frame(matrix(rep(NA, pori_sm), nrow=1))[numeric(0), ]
    
    # 楕円周上の点の座標を取得
    for(j in 1:nrow(temp_WsiteD)){
      # 長軸（半分）
      t_a <- temp_WsiteD$long_axis[j]/2
      # 短軸（半分）
      t_b <- temp_WsiteD$short_axis[j]/2
      # 回転角
      t_theta <- temp_WsiteD$shrub_dir.E0_left.[j] * pi / 180
      # 中心のx座標
      t_cenx <- temp_WsiteD$x[j]
      # 中心のy座標
      t_ceny <- temp_WsiteD$y[j]
      
      # 楕円周上の点の座標
      t_x <- t_a * cos(base_x) * cos(t_theta) - t_b * sin(base_x) * sin(t_theta) + t_cenx
      t_y <- t_a * cos(base_x) * sin(t_theta) + t_b * sin(base_x) * cos(t_theta) + t_ceny
      
      t_x <- data.frame(rbind(t_x))
      row.names(t_x) <- j
      t_y <- data.frame(rbind(t_y))
      row.names(t_y) <- j
      
      shrb_px <- rbind(shrb_px,t_x)
      shrb_py <- rbind(shrb_py,t_y)
    }
  
  ### streetを計算
    ## street計算時の直線の座標取得
    # basiangleにはサイト上E0leftのサイト方位を入れる
    i_baseangle <- temp_WsiteD$SiteDir.E0_left.[1]
    lineang <- 360 - (sepangle - i_baseangle ) # 30方位(0<180)についてE0leftでsite angleを考慮表記
    linepointx <- flinepointx_wd(sepcounts,sepangle,i_baseangle)
    linepointy <- flinepointy_wd(sepcounts,sepangle,i_baseangle)
    
    # PCの座標分平行移動
    i_linepointx <- linepointx + temp.pc$x
    i_linepointy <- linepointy + temp.pc$y
    
    ## そもそも20mや0mを超えている部分は不要
    # 両方0以上20以下である範囲を取得
    i_linepointx.t <- i_linepointx <= 22 & i_linepointx >= -2
    i_linepointy.t <- i_linepointy <= 22 & i_linepointy >= -2
    # 両方0以上20以下であるような直線の座標
    i_linepointx2 <- i_linepointx[i_linepointx.t & i_linepointy.t]
    i_linepointy2 <- i_linepointy[i_linepointx.t & i_linepointy.t]
  
    # ポリゴン内外チェック結果格納リスト
    res <- list() 
    
    ## 灌木と直線の交点チェック
    for (ishrb in 1:nrow(temp_WsiteD)) {
      # 直線上の点でポリゴンの内外をチェック。0のときのみポリゴン外
      res[[ishrb]] <- point.in.polygon(i_linepointx2, i_linepointy2, 
                                       shrb_px[ishrb,], shrb_py[ishrb,])
    }
    res2 <- sapply(res,sum)
    if (sum(res2) == 0) {
      # 交点がないときは線分の長さを入れる
      temp.val <- (i_linepointx2[length(i_linepointx2)] - i_linepointx2[1]) / 
        cos(lineang * pi / 180)
      temp.result <- rbind(temp.result,c(temp.siteev,temp.pc$PC_No,0 ,temp.val,0,0))
    }else{ # 交点が一つ以上あったとき
      for(i_res in 1:length(res2)){
        if(res2[i_res] != 0){
          startflag <- TRUE
          endflag <- FALSE
          for (i_line in 1:length(res[[i_res]])) {
            if (res[[i_res]][i_line] == 0 & startflag) {
              i_start <- i_line
              startflag <- FALSE
              endflag <- TRUE
            }else if(res[[i_res]][i_line] != 0 & endflag){
              i_end <- i_line
              
              temp.val.st <- (i_linepointx2[i_end] - temp.pc$x) / 
                cos(lineang * pi / 180)
              temp.val.en <- (i_linepointx2[i_start] - temp.pc$x) / 
                cos(lineang * pi / 180)
              temp.val <- max(c(temp.val.st,temp.val.en))
              temp.sh.h <- temp_WsiteD$height[i_res]
              temp.result <- rbind(temp.result,c(temp.siteev,temp.pc$PC_No,i_res ,temp.val,temp.sh.h,(temp.sh.h/temp.val)))
              startflag <- TRUE
              endflag <- FALSE
            }
          }
        }
      }
    }
    colnames(temp.result) <-df.colnames
  }
    
    ## 結果のプロット
    if(!is.na(which(i_pc == initsite)[1])){
      if(i_pc != 1){
        dev.copy(cairo_pdf, file=
                 paste("Erodibility/shrub_distibution_pcstreet",WPCcoord$SiteID[(i_pc-1)],".pdf", sep = ""),
                 width = 10, height = 10)
        dev.off()
      }
      # 枠
      par(family = family_serif)
      plot.new()
      plot.window(xlim=c(-2, 22), ylim=c(-2, 22)) 
      for (j in 1:4) {
        axis(side = j, at=seq(0, 20, by = 5))
      }
      for (j in 0:20) {
        segments(j, 0, j, 20)
        segments(0, j, 20, j)
      }
      for (j in 0:4) {
        abline(h = j*5, lty=3)
        abline(v = j*5, lty=3)
      }
      
      # 灌木のポリゴンプロット
      for(i_shrub in 1:nrow(shrb_px)){
        polygon(shrb_px[i_shrub,] ,shrb_py[i_shrub,],col = gray(1 - temp_WsiteD$height[i_shrub] / max_h))
      }
      
      # サイト方位記号
      arrows(-1.5, 21.5, cos(i_baseangle * pi / 180) - 1.5,
             sin(i_baseangle * pi / 180) + 21.5 ,angle = 15, length = 0.15)
      text(1.3* cos(-i_baseangle * pi / 180) - 1.5,
           1.3 * sin(i_baseangle * pi / 180) + 21.5, "N")
      
      # 灌木高さ凡例
      for(j in 1:10){
        rect(22, 4+j, 21.5,  5+j, border = TRUE,col=gray(1 - j/10))
      }
      text(22.5,5,min_h)
      text(22.5,15,max_h)
      text(22.5,10,"shrub height (m)",adj = 0.5 ,srt=90 )
      
      # 灌木のみマップ保存
      dev.copy(cairo_pdf, file=
                 paste("Erodibility/shrub_distibution",WPCcoord$SiteID[i_pc],".pdf", sep = ""),
               width = 10, height = 10)
      dev.off()
    }

    # PCポイント
    if(is.na(which(c("l","m","h") == temp.pc$PC_No)[1])){
      points(temp.pc$x,temp.pc$y,pch = 8, cex=2)
      text(temp.pc$x,temp.pc$y-1, paste("pc_", temp.pc$PC_No,sep = ""), cex=1.1)
    }else{
      points(temp.pc$x,temp.pc$y,pch = 7, cex=2)
      text(temp.pc$x,temp.pc$y-1, paste("wm_", temp.pc$PC_No,sep = ""), cex=1.1)
    }
    
    
  if(temp.pc$Event != 99){
    # PCからの直線
    lines(i_linepointx2,i_linepointy2,col = 2,lwd = 2)
    
    # 直線に交わる灌木の色変え
    for(i_shrub in 1:nrow(shrb_px)){
      if (!is.na(which(temp.result$shrubNo == i_shrub)[1])) {
        polygon(shrb_px[i_shrub,] ,shrb_py[i_shrub,],col = NA,
                border = 2)
      }
    }
  }
    
    # 最後の保存
    if(i_pc == nrow(WPCcoord)){
      dev.copy(cairo_pdf, file=
                 paste("Erodibility/shrub_distibution_pcstreet",WPCcoord$SiteID[(i_pc-1)],".pdf", sep = ""),
               width = 10, height = 10)
      dev.off()
    }

  ## 結果格納
    result.shrb.distr <- rbind(result.shrb.distr,temp.result)

  setTxtProgressBar(pb, i_pc) 
}
colnames(result.shrb.distr) <-df.colnames
# 結果出力
write.csv(result.shrb.distr, paste("Erodibility/shrub_dist.csv", sep = ""),row.names=FALSE)
toc()

# Functions ---------------------------------------------------------------

flinepointx_wd <- function(count,evwd,abaseangle){
  # evwdはN0rightのイベントごとの風向
  
  output <- data.frame(matrix(NA, nrow=2*count-1, ncol = 1))
  colnames(output) <- evwd # 出力データフレームの列名はN0rightの方位角
  reprang <- 360 - (evwd - abaseangle ) # E0leftで表記
  temp.line <- seq(0,length = count, by = sqrt(2)*cos(reprang * pi / 180) / 50)
  temp.line <- c(rev(-temp.line),temp.line[2:length(temp.line)])
  
  output[,1] <- temp.line
  return(output)
}
flinepointy_wd <- function(count,evwd,abaseangle){
  # evwdはN0rightのイベントごとの風向
  
  output <- data.frame(matrix(NA, nrow=2*count-1, ncol = 1))
  colnames(output) <- evwd # 出力データフレームの列名はN0rightの方位角
  reprang <- 360 - (evwd - abaseangle ) # E0leftで表記
  
  temp.line <- seq(0,length = count, by = sqrt(2)*sin(reprang * pi / 180) / 50)
  temp.line <- c(rev(-temp.line),temp.line[2:length(temp.line)])
  
  output[,1] <- temp.line
  return(output)
}

