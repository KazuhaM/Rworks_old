
# 関数読み込み ------------------------------------------------------------------
originalWD.path <- getwd()
cordpath <- "D:/Documents/Rworks/2021Mongilia_NBsites"
setwd(cordpath)
source("Okin_functions.r")

mathfunc.path <- "D:/Documents/Rworks/Functions"
setwd(mathfunc.path)
source("MathematicalFunctions.r")
source("DataframeFunctions.r")
setwd(originalWD.path)


#  model指標算出 -------------------------------------------------------------------

# ある直線liについてのmodel.new

cul.model.new <- function(lphi, us,lambda,pc, ldist,  shrub.data,ustr,
                          xsitesize = c(0,20),ysitesize = c(0,20),septime = 1000){
  if(nrow(shrub.data) != 0) {
    ### 直線データ作成
    # 灌木データ用意、灌木に通し番号を振る
    shrub.data$sn <- 1:length(shrub.data$alpha)
    
    # 直線データ（x軸上）作成
    l_xaxis <- make.xline.inrange(pc,lphi,ldist)
    byline <- (xsitesize[2] - xsitesize[1]) * sqrt(2) / septime # 直線を示す点列の点間距離d
    
    # 直線がサイト範囲と交差するかどうかで場合分け
    # 直線とサイト境界線の交点のうち、PC座標から遠い方とPCとの距離がi_dist(ldist)より短い場合も、
    # NAを返すので、場合分けされる
    if(is.data.frame(l_xaxis)){
      # 直線liをx軸上からpcを通る直線に変換
      l <- as.data.frame(cbind(point.translate(point.rotate(l_xaxis[,c("lp_x","lp_y")],lphi),pc[1], pc[2]),
                               l_xaxis$ln))
      colnames(l) <- c("lp_x","lp_y","ln")
      
      ### 直線と交点を持つ灌木の抽出
      {
        # 総当りデータ作成
        data <- round.robin.data(l,shrub.data)
        
        # 各点の楕円内外判定
        data.inout <- point.in.ellipse(data[,c("lp_x","lp_y")],data$alpha,data$beta,data$a,data$b,data$theta)
      }
      
      # 楕円に一つもヒットしなかった場合と場合分け
      if(sum(data.inout) != 0){
        # 直線と交点を持つ楕円と、それに内包される直線lの点を抽出
        data.in <- data[data.inout,]
        
        ### ある点P_iについて、風上直近の灌木の高さhiおよびその灌木までの距離xiを取得
        {
          ## 高さ算出
          hi <- cul.z.ellipse(data.in[,c("lp_x","lp_y")],
                              data.in$alpha,data.in$beta,
                              data.in$a,data.in$b,data.in$c,data.in$theta)
          # hiに座標データを結合させる
          data.in2 <- cbind(data.in,hi)
          data.in2 <- data.in2[order(data.in2$ln),]
          data.in2 <- large.duplicated(data.in2,"ln","hi") # 同じl上の点について、2つ以上の灌木の影響があった場合、より影響の強い方を採用
          data.in2 <- data.in2[,c("ln","hi")]
          
          # 直線lの全体のデータにhiの情報を結合
          l_hi <- merge(l,data.in2,by="ln",all.x=T )
          l_hi$hi[is.na(l_hi$hi)] <- 0 #高さがない（灌木と交差していない）場所は0にする
          
          ### PCからの距離行列作成
          mat_i <- mapply(rep,l_hi$ln,length(l_hi$ln))
          mat_i <- matrix(as.matrix(mat_i),nrow(mat_i),ncol(mat_i))
          mat_j <- l_hi$ln
          pDist <- (mat_i - mat_j) * byline
        }
        
        ### hi, xiからus*/u*を算出 
        {
          # 灌木高さの逆数ベクトル用意
          hvec <- 1/l_hi$hi
          
          # 距離を高さで割る。つまりxij/hjを算出する
          xh <- t(hvec * t(pDist))
          
          # 同じ点同士のペア、i>jの点について調整
          xh[lower.tri(xh)] <- NA #i > jとなるペア
          diag(xh) <- 0 # 同じ点同士のペアは距離が0なので一旦0にしておく
          # xh[is.infinite(xh)] <- NA # 高さ0のペア
          # diag(xh) <- NA # 同じ点同士のペア
          
          
          # u*s 計算
          uss <- okin.eq4(xh) * us
          # もっとも抑えられた摩擦速度を抽出
          uss[is.na(uss)] <- Inf # 最小値を取るので必要ない場所は最大にしておく
          diag(uss)[l_hi$hi == 0] <- us # 同じ点同士のペアで灌木外の点（高さ0）は、影響を受けないのでusそのまま
          uss.min <-apply(uss,1,min)
        }
        
        ### us*t とλからu*tを算出
        ust <- ust.bare.veg.trans(ustr,lambda)
        
        ### us*とu*tからq_piを算出
        # q.pi <- mapply(okin.eq5,uss.min, rep(ust,length = length(uss.min)) )
        # q.pi <- future_map2_dbl(uss.min, ust,okin.eq5)
        q.pi <- okin.eq5(uss.min, ust)
      }else{
        ### 直線と灌木が交差しなかった場合
        # u*t算出
        ust <- ust.bare.veg.trans(ustr,lambda)
        # us算出（全点において同じus）
        uss <- us
        q.pi <- okin.eq5(uss, ust)
        
      }
      ### 直線上のq_piを平均して、q_liを算出
      q.li <- mean(q.pi)
    }else{
      # 直線がサイト範囲と交わらなかった場合
      q.li <- NA
    }
  }else{
    ### 直線と灌木が交差しなかった場合
    # u*t算出
    ust <- ust.bare.veg.trans(ustr,lambda)
    # us算出（全点において同じus）
    uss <- us
    q.pi <- okin.eq5(uss, ust)
    q.li <- mean(q.pi)
  }
  

  ### 出力
  return(q.li)
  
}


# ある直線liについてのmodel.okin

cul.model.okin <- function(lphi, us,lambda,pc, ldist, aveh,  shrub.data,ustr,
                          xsitesize = c(0,20),ysitesize = c(0,20),septime = 1000){
  if(nrow(shrub.data) != 0) {
    ### 直線データ作成
    # 灌木データ用意、灌木に通し番号を振る
    shrub.data$sn <- 1:length(shrub.data$alpha)
    
    # 直線データ（x軸上）作成
    l_xaxis <- make.xline.inrange(pc,lphi,ldist)
    byline <- (xsitesize[2] - xsitesize[1]) * sqrt(2) / septime # 直線を示す点列の点間距離d
    
    # 直線がサイト範囲と交差するかどうかで場合分け
    # 直線とサイト境界線の交点のうち、PC座標から遠い方とPCとの距離がi_dist(ldist)より短い場合も、
    # NAを返すので、場合分けされる
    if(is.data.frame(l_xaxis)){
      # 直線liをx軸上からpcを通る直線に変換
      l <- as.data.frame(cbind(point.translate(point.rotate(l_xaxis[,c("lp_x","lp_y")],lphi),pc[1], pc[2]),
                               l_xaxis$ln))
      colnames(l) <- c("lp_x","lp_y","ln")
      
      ### 直線と交点を持つ灌木の抽出
      {
        # 総当りデータ作成
        data <- round.robin.data(l,shrub.data)
        
        # 各点の楕円内外判定
        data.inout <- point.in.ellipse(data[,c("lp_x","lp_y")],data$alpha,data$beta,data$a,data$b,data$theta)
      }
  
      
      # 楕円に一つもヒットしなかった場合と場合分け
      if(sum(data.inout) != 0){
  
        # 直線と交点を持つ楕円と、それに内包される直線lの点を抽出
        ## 高さはサイト平均高
          # hiに座標データを結合させる
          hi <- rep(aveh,nrow(data[data.inout,]))
          data.in2 <- cbind(data[data.inout,],hi)
          data.in2 <- data.in2[order(data.in2$ln),]
          data.in2 <- large.duplicated(data.in2,"ln","hi") # 同じl上の点について、2つ以上の灌木の影響があった場合、より影響の強い方を採用
          data.in2 <- data.in2[,c("ln","hi")]
          
          # 直線lの全体のデータにhiの情報を結合
          l_hi <- merge(l,data.in2,by="ln",all.x=T )
          l_hi$hi[is.na(l_hi$hi)] <- 0 #高さがない（灌木と交差していない）場所は0にする
          
        # 距離ベクトル作成
          formals(which.over0.afteri.d)$vec <- l_hi$hi
          formals(which.over0.afteri.h)$vec <- l_hi$hi
          near.sh.dist <- sapply(1:length(l_hi$hi),which.over0.afteri.d)
          near.sh.hi.d <- sapply(1:length(l_hi$hi),which.over0.afteri.h)
          pDist <- near.sh.dist * byline
          
        # 各点において使うべき高さ
          near.sh.hi <- l_hi$hi[near.sh.hi.d]
        
        ### hi, xiからus*/u*を算出 
        {
          # 灌木高さの逆数ベクトル用意
          hvec <- 1/near.sh.hi
          
          # 距離を高さで割る。つまりxij/hjを算出する
          xh <- hvec * pDist
          
          # u*s 計算
          uss <- okin.eq4(xh) * us
          # もっとも抑えられた摩擦速度を抽出
          uss[is.na(uss)] <- us # 最小値を取るので必要ない場所は最大にしておく
        }
        
        ### us*t とλからu*tを算出
        ust <- ust.bare.veg.trans(ustr,lambda)
        
        ### us*とu*tからq_piを算出
        # q.pi <- mapply(okin.eq5,uss.min, rep(ust,length = length(uss.min)) )
        # q.pi <- future_map2_dbl(uss.min, ust,okin.eq5)
        q.pi <- okin.eq5(uss, ust)
      }else{
        ### 直線と灌木が交差しなかった場合
        # u*t算出
        ust <- ust.bare.veg.trans(ustr,lambda)
        # us算出（全点において同じus）
        uss <- us
        q.pi <- okin.eq5(uss, ust)
        
      }
      ### 直線上のq_piを平均して、q_liを算出
      q.li <- mean(q.pi)
    }else{
      # 直線がサイト範囲と交わらなかった場合
      q.li <- NA
    }
  }else{
    ### 直線と灌木が交差しなかった場合
    # u*t算出
    ust <- ust.bare.veg.trans(ustr,lambda)
    # us算出（全点において同じus）
    uss <- us
    q.pi <- okin.eq5(uss, ust)
    q.li <- mean(q.pi)
  }
  
  ### 出力
  return(q.li)
  
}






