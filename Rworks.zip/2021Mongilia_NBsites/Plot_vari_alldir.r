
# library -----------------------------------------------------------------

library(sp)
library(tcltk2)
# library("fmsb")
library("RColorBrewer")
library(plotrix)
# 内外の判定 0 : 領域外の点 1 : 領域内の点 2 : 境界上の点(辺) 3 :境界上の点(頂点)
# res <- point.in.polygon(x, y, pol.x, pol.y)


# main --------------------------------------------------------------------
path <- "D:/OneDrive - g.ecc.u-tokyo.ac.jp/LEP/2020/00working/1301MongoliaAnalysis8/ShrubDistribution"
setwd(path)

variall <- read.csv("all_vari.csv",header = T)
variall$SiteID  <- as.factor(variall$SiteID )
sites <- levels(variall$SiteID)

variuni <- read.csv("uni_vari.csv",header = T)
variuni$SiteID <- as.factor(variuni$SiteID)
variuni$degree <- 90 - variuni$degree

for (i_site in 1:length(sites)) {
  temp.vari.a <- variall[variall$SiteID == sites[i_site],]
  t.variuni <- variuni[variuni$SiteID == sites[i_site],]
  
  plot.vari.a <- t(temp.vari.a[,c("effective_range")])
  plot.vari.a <- as.vector(plot.vari.a)
  # plot.vari.a <- c(plot.vari.a ,plot.vari.a )
  plot.vari.a2 <- result.shrb.distr <- data.frame(matrix(rep(NA, 30), nrow=1))
  plot.vari.a2[,seq(1,15,by = 2)] <- plot.vari.a
  plot.vari.b = plot.vari.a[2:length(plot.vari.a)] + plot.vari.a[-length(plot.vari.a)]
  plot.vari.a2[,seq(2,14,by = 2)] <- plot.vari.b / 2
  
  plot.vari.a2[,seq(16,30,by = 2)] <- plot.vari.a
  plot.vari.a2[,seq(17,29,by = 2)] <- plot.vari.b / 2
  plot.vari.a2 <- as.data.frame(plot.vari.a2)
  colnames(plot.vari.a2) <- seq(0,360-12,by = 12)
  plot.vari.a2 <- as.vector(plot.vari.a2)

  # 異方性バリオグラム
  par(mar = c(1,1,1,1),xpd=F,family = family_serif)
  
  radial.plot(plot.vari.a2[!is.na(plot.vari.a2)], 
              line.col = 1,lwd = 2.5,lty = 1,
              labels = colnames(plot.vari.a2),
              rp.type="p",
              show.grid.labels = 3,
              radial.lim =seq(0,15,length = 5),
              rad.col =adjustcolor("gray", alpha=1),
              grid.col = adjustcolor("gray", alpha=1),
              start=(temp.vari.a$siteDir[1]-270)*pi/180,clockwise=TRUE
              )
  # WDごとの値をプロット
  WDr_x <- t.variuni$effective_range * cos(t.variuni$degree * pi / 180)
  WDr_y <- t.variuni$effective_range * sin(t.variuni$degree * pi / 180)
  points(WDr_x,WDr_y,pch = 16,col = 1)
  
  arrows(0, 0, cos((temp.vari.a$siteDir[1]-270) * pi / 180) * 15,
         sin((temp.vari.a$siteDir[1]-270) * pi / 180)* 15  ,angle = 15, length = 0.15,lwd = 2,
         col = "gray")
  
  dev.copy(cairo_pdf, file=paste("shp_forVariogram/plot_alldir/LC_rosePlot_",sites[i_site],".pdf",sep=""), width = 10, height = 10)
  dev.off()
  # マーカー
  print(paste(i,"/",length(site_name),"まで終了",sep ="" ))
}


# Functions ---------------------------------------------------------------

flinepointx <- function(seppi,count,abaseangle){
  # base angleはサイト上E0leftのサイト方位を入れれば良い
  sepang <- 360/seppi
  reprang <- seq(0, 360-sepang, by = sepang)
  reprang <- reprang[1:(seppi/2)]
  output <- data.frame(matrix(NA, nrow=2*count-1, ncol = (seppi/2)))
  colnames(output) <- reprang # 出力データフレームの列名はN0rightの方位角
  reprang <- abaseangle- reprang # E0leftで表記
  i_col = 1
  for(tiangx in reprang){
    temp.line <- seq(0,length = count, by = sqrt(2)*cos(tiangx * pi / 180) / 50)
    temp.line <- c(rev(-temp.line),temp.line[2:length(temp.line)])
    output[,i_col] <- temp.line
    i_col <- i_col + 1
  }
  return(output)
}
flinepointy <- function(seppi,count,abaseangle){
  sepang <- 360/seppi
  reprang <- seq(0, 360-sepang, by = sepang)
  reprang <- reprang[1:(seppi/2)]
  output <- data.frame(matrix(NA, nrow=2*count-1, ncol = (seppi/2)))
  colnames(output) <- reprang # 出力データフレームの列名はN0rightの方位角
  reprang <- abaseangle- reprang # E0leftで表記
  i_col = 1
  for(tiangy in reprang){
    temp.line <- (seq(0,length = count, by = sqrt(2)*sin(tiangy * pi / 180) / 50))
    temp.line <- c(rev(-temp.line),temp.line[2:length(temp.line)])
    output[,i_col] <- temp.line
    i_col <- i_col + 1
  }
  return(output)
}

