
# 必要データ
# 灌木分布データ、PC位置情報

# 繰り返し項目
# 灌木の影響範囲の高さに対する倍率 {n|n = 1,3,5,10,25,50}
# 考慮する角度範囲　{ang | ang = 0,15,30,45}
# PC {i_PC | i_PC = 1 : length(PC)}
# 灌木それぞれ

# 直線を決める
# 直線に交点を持つ灌木を選定する


# Init --------------------------------------------------------------------

tic()
# working directory
path <- "D:/OneDrive - g.ecc.u-tokyo.ac.jp/LEP/2020/00working/1301MongoliaAnalysis8/ShrubDistribution"
setwd(path)

# 灌木情報
WsiteD <- read.csv("WsiteShrubDistribution.csv",header = T)

# PC座標
WPCcoord <- read.csv("WsitePCDistribution.csv",header = T)

# 各サイトの始まりを取得
sites <- c("W2-3","W2-5","W3-3","W3-4")
initsite <- c()
for (i_row in 1:length(sites)) {
  initsite <- c(initsite,which(WPCcoord$SiteID == sites[i_row])[1])
}

# イベント風向(N0right)
eventwd <- c(245.6537782, # W2-3_4
             272.0940444, # W2-3_5
             63.42984944, # W2-3_6
             276.8279183, # W2-5_1
             291.2269448, # W3-3_1
             242.2881938) # W3-4_1
eventname <- c("W2-3_4","W2-3_5","W2-3_6","W2-5_1","W3-3_1","W3-4_1")
eventwd <- as.data.frame(eventwd)
eventwd$siteev <- eventname

# PCから風上に伸ばす直線のための変数
septime <- 1
sepcounts <- 1002

## 結果格納用データベースresult.shrb.distrに行を追加
result.shrb.distr <- data.frame(matrix(rep(NA,6), nrow=1))[numeric(0), ]
df.colnames <- c("site_ev","PC_No","shrubNo","d", "h", "h/d")
colnames(result.shrb.distr) <-df.colnames
pb <- txtProgressBar(min = 1, max = nrow(WPCcoord), style = 3)

for (i_pc in 1:nrow(WPCcoord)) {
  ### 準備
  
    # 該当サイト-イベント-PC のPCデータを抽出
    temp.pc <- WPCcoord[i_pc,] 
  
    if(temp.pc$Event != 99){ #飛砂を測定しているPCのデータのみ計算
      # 該当サイト-イベントの灌木データを抽出
      temp_WsiteD <- WsiteD[WsiteD$Site == temp.pc$SiteID,]
      
      # イベント風向
      temp.siteev <- paste(temp.pc$SiteID,"_",temp.pc$Event,sep = "") # site event name
      sepangle <- eventwd$eventwd[which(eventwd$siteev == temp.siteev)[1]] # イベント風向取得
      
      ### 楕円ポリゴンの作成 
      shrb_px <- data.frame(matrix(rep(NA, pori_sm), nrow=1))[numeric(0), ]
      shrb_py <- data.frame(matrix(rep(NA, pori_sm), nrow=1))[numeric(0), ]
      
      # 楕円周上の点の座標を取得
      for(j in 1:nrow(temp_WsiteD)){
        # 長軸（半分）
        t_a <- temp_WsiteD$long_axis[j]/2
        # 短軸（半分）
        t_b <- temp_WsiteD$short_axis[j]/2
        # 回転角
        t_theta <- temp_WsiteD$shrub_dir.E0_left.[j] * pi / 180
        # 中心のx座標
        t_cenx <- temp_WsiteD$x[j]
        # 中心のy座標
        t_ceny <- temp_WsiteD$y[j]
        
        # 楕円周上の点の座標
        t_x <- t_a * cos(base_x) * cos(t_theta) - t_b * sin(base_x) * sin(t_theta) + t_cenx
        t_y <- t_a * cos(base_x) * sin(t_theta) + t_b * sin(base_x) * cos(t_theta) + t_ceny
        
        t_x <- data.frame(rbind(t_x))
        row.names(t_x) <- j
        t_y <- data.frame(rbind(t_y))
        row.names(t_y) <- j
        
        shrb_px <- rbind(shrb_px,t_x)
        shrb_py <- rbind(shrb_py,t_y)
      }
        
    }  # if(event != 99) の終わり
}　# for i_PCの終わり

  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
