### Model_Okinのための関数群
## 灌木保護範囲下にある領域での摩擦速度us*とu*との比（u*s / u*）を算出する
# expの中身（-xij / (c1 * hj)）をまるごと与える
okin.eq4 <- function(xh, b0 = 0.32,c1 = 4.8){
  output <- b0 + (1 - b0) * (1 - exp(-xh / c1))
  return(output)
}

## Owen(1964)の式(q(g / s m2))
# 値のみ対応
okin.eq5 <- function(uss, ust, A = 1, rho = 1293, g = 9.8){
  up.bool <- uss < ust
  
  output <- A * rho * uss * (uss^2 - ust^2) / g
  output[up.bool] <- 0

  return(output)
}

## 臨界摩擦速度の変換
# 臨界摩擦速度を粗度要素のある面での値（u*tr）と
# 理想裸地面（smooth sufrace without roughness elements, u*ts）での値とで変換する
# 入力は粗度要素のある面での臨界摩擦速度、出力は理想裸地面での臨界摩擦速度
ust.bare.veg.trans <- function(ustr, lambda, sigma = 1, m = 0.5, beta = 200){
  output <- ustr / sqrt((1 - m * sigma * lambda) * (1 + m * beta * lambda))
  return(output)
}