# library -----------------------------------------------------------------
library(tidyverse)
library(furrr)
plan(multisession, workers = 7)
options(scipen=5)

# 関数読み込み ------------------------------------------------------------------
originalWD.path <- getwd()
mathfunc.path <- "D:/Documents/Rworks/Functions"
setwd(mathfunc.path)
source("MathematicalFunctions.r")
source("DataframeFunctions.r")
setwd(originalWD.path)


#  指標算出 -------------------------------------------------------------------
## Hae
# 必要データ：ある直線の点列データ(PCの座標（pcx, pcy）、風向phi（サイト上E0left）)（単独の値）
#             直線と交点を持つすべての灌木について楕円方程式(alpha, beta, a, b, c, theta)（すべてベクトル形式）

# 直線を示す点列(長さn)の作成。点間の感覚は等しくしておく
#   直線はx軸に平行、原点を通るように作成する
# 点列の各点lp_iについて、そのときの高さをh_iとする
#   楕円内判定→楕円内にあるものについて、楕円方程式からz座標算出→ z = h_i
#   回転前の式を使う。各直線の点lp_iをtheta回転、（pcx, pcy）平行移動して、この点について判定を行う。
# 
# hvecにh_iの逆数を代入。このとき、第一項から順に、PCに近い順の点列を表す（i =1,2,3,...,n-1,n）
# ある点iについて、そこからペアとなるよりPCから遠い点をjとする。
# このとき、H_{ae_i, var} = 0.68 * exp(-d * (j - i) / 4.8 h_j)
# ここでdは直線lについて、点列の間隔。これは等しくしておく
# hvecに下のような行列を掛けて、d, 1/4.8, -1を更に駆ける。これをexpにいれ、0.68倍するとH_{ae_i, var}が出る。
# H_{ae_i, var}の行列を上三角行列化したのち、各行の最大値がH_ae_iとなる。これを返す
cul.hae <- function(lphi,pc, shrub.data,ldist,
                    xsitesize = c(0,20),ysitesize = c(0,20),septime = 1000,c1 = 4.8, b0 = 0.32){
  ### 各座標における高さh_iを算出
  ## 総当りデータ作成
  # 灌木データ
  
  shrub.data$sn <- 1:length(shrub.data$alpha)
  # colnames(shrub.data) <- c("alpha", "beta", "a", "b", "c", "theta","sn")
  # 直線データ（x軸上）
  l_xaxis <- make.xline.inrange(pc,lphi,ldist)
  byline <- (xsitesize[2] - xsitesize[1]) * sqrt(2) / septime # 直線を示す点列の点間距離d
  
  # 直線がサイト範囲と交差するかどうかで場合分け
  # 直線とサイト境界線の交点のうち、PC座標から遠い方とPCとの距離がi_dist(ldist)より短い場合も、
  # NAを返すので、場合分けされる
  if(is.data.frame(l_xaxis)){
    # 直線lをx軸上からpcを通る直線に変換
    l <- as.data.frame(cbind(point.translate(point.rotate(l_xaxis[,c("lp_x","lp_y")],lphi),pc[1], pc[2]),
                             l_xaxis$ln))
    colnames(l) <- c("lp_x","lp_y","ln")
    # 総当りデータ
    data <- round.robin.data(l,shrub.data)
    
    # 各点の楕円内外判定
    data.inout <- point.in.ellipse(data[,c("lp_x","lp_y")],data$alpha,data$beta,data$a,data$b,data$theta)
    # 楕円に一つもヒットしなかった場合と場合分け
    if(sum(data.inout) != 0){
      # 直線と交点を持つ楕円と、それに内包される直線lの点を抽出
      data.in <- data[data.inout,]
      
      # 高さ算出
      hi <- cul.z.ellipse(data.in[,c("lp_x","lp_y")],
                          data.in$alpha,data.in$beta,
                          data.in$a,data.in$b,data.in$c,data.in$theta)
      # hiに座標データを結合させる
      data.in <- cbind(data.in,hi)
      data.in <- data.in[order(data.in$ln),]
      data.in <- large.duplicated(data.in,"ln","hi") # 同じl上の点について、2つ以上の灌木の影響があった場合、より影響の強い方を採用
      data.in2 <- data.in[,c("ln","hi")]
      
      # 直線lの全体のデータにhiの情報を結合
      l_hi <- merge(l,data.in2,by="ln",all.x=T )
      l_hi$hi[is.na(l_hi$hi)] <- 0 #高さがない（灌木と交差していない）場所は0にする
      
      ### それぞれの点の、風下に対する影響度計算
      # 計算方法は上参照

      # 灌木高さの逆数ベクトル用意
      hvec <- 1/l_hi$hi
      
      # PCからの距離行列作成
      mat_i <- mapply(rep,l_hi$ln,length(l_hi$ln))
      mat_i <- matrix(as.matrix(mat_i),nrow(mat_i),ncol(mat_i))
      mat_j <- l_hi$ln
      A <- (mat_i - mat_j) * byline
      
      # 距離を高さで割る
      A <- -hvec * t(A)
      # 0で除算したもの、同じ点同士のペアについて、NAを代入（後で影響力0にする）
      A[is.infinite(A)] <- NA
      A[is.nan(A)] <- NA
      
      # Haei_var計算
      A <- t(A) / c_1
      Haei_var <- (1 - b0) * exp(A)
      # 0で除算したもの、同じ点同士のペアについて影響度0
      Haei_var[lower.tri(Haei_var)] <- 0
      Haei_var[is.na(Haei_var)] <- 0
      
      # ある点iに対し、最も強い影響力を持つ点jの影響力を抽出
      Haei <-apply(Haei_var,1,max)
      
      ## ある直線に関するHae（一つの値）を算出
      # 各点のPCまでの距離xでHaeを補正
      # 距離xのデータはx座標上に設置したlのx座標より取得
      Hae <- sum(correction.distance(Haei,l_xaxis$lp_x))
    }else{
      # print("there are no shrubs crossing the line")
      # 一つも灌木と交差しないとき、その影響力は0とする
      Hae <- 0
    }
  }else{
    Hae <- NA
  }

  return(Hae)
}

## M_Okin
cul.sf.okin <- function(){
  
  
}


## street'
cul.street.dist <- function(lphi, pc, sh.data, ldist,
                            xsitesize = c(0,20),ysitesize = c(0,20)){
  # 直線作成
  # y = tan(lphi) * (x - pc[1]) + pc[2]
  # 直線と直線の範囲
  # 直線が水平、垂直の場合を分ける
  if(lphi %% pi == 0){
    if(pc[2] >= 0 & pc[2] <= 20){
      line.range <- data.frame(x = xsitesize, y = c(pc[2],pc[2]))
    }else{
      line.range <- data.frame(x = c(NA,NA), y = c(NA,NA))
    }
  }else if(lphi %% (pi/2) == 0){
    if(pc[1] >= 0 & pc[1] <= 20){
      line.range <- data.frame(x = c(pc[1],pc[1]), y = ysitesize)
    }else{
      line.range <- data.frame(x = c(NA,NA), y = c(NA,NA))
    }
  }else{
    line.range <- length.line.in.range(pc[2] - pc[1] * tan(lphi), tan(lphi))
  }
  ## phiの値でline.ragenのどの値が、線分のPCと逆側の端点かを判定する
  line.range2 <- c(NA,NA)
  if(sum(!is.na(line.range)) != 0){
    if(lphi >= pi/2 | lphi <= -pi/2){
      if(pc[1] >= line.range[1,1]){
        line.range2 <- line.range[1,]
      }
    }else{
      if(pc[1] <= line.range[2,1]){
        line.range2 <- line.range[2,]
      }
    }
  }
  
  if(!is.na(sum(line.range2))){
    if(distance.points(pc, line.range2) >= ldist){
      
      if(nrow(sh.data) !=0){
        # 直線と灌木の交点チェック
        data.inout <- ellipse.line.cross(pc[1], pc[2],lphi,
                                         sh.data$alpha, sh.data$beta, 
                                         sh.data$a, sh.data$b, sh.data$theta)
        # 交差しているものがあるかどうか
        if(sum(data.inout) != 0){ # あるならこちら
          data.in <- sh.data[data.inout,]
          crosspoints <- ellipse.line.cross.point(pc, lphi, data.in)
          # 個別streetデータ格納先
          streets <- rep(NA, length = nrow(crosspoints) + 1)
          for(i_st in 1:(nrow(crosspoints) + 1)){
            if(i_st == 1){# 直線上の最もPCに近い灌木との交点は、PCとの距離をstreetとする
              streets[i_st] <- distance.points(pc, crosspoints[i_st,c("x1","y1")])
              streets[i_st] <- correction.distance(streets[i_st],distance.points(pc,pc) )
            }else if(i_st == (nrow(crosspoints) + 1)){# 直線上のPCから最も遠い灌木との交点は、線分の端点との距離をstreetとする
              # x座標にて、PCから遠い方を線分のPC逆側の端点として、灌木との交点との距離を算出する。
              streets[i_st] <- distance.points(crosspoints[i_st - 1,c("x2","y2")], line.range2)
              streets[i_st] <- correction.distance(streets[i_st],
                                                   distance.points(pc,crosspoints[i_st - 1,c("x2","y2")]) )
            }else{# 灌木間の距離を測定しstreetとする
              streets[i_st] <- distance.points(crosspoints[i_st - 1,c("x2","y2")],
                                               crosspoints[i_st,c("x1","y1")])
              streets[i_st] <- correction.distance(streets[i_st],
                                                   distance.points(pc,crosspoints[i_st - 1,c("x2","y2")]) )
            }
            
          }
          street.dist <- sum(streets)
        }else{ # 交差する灌木がない場合、線分の長さを結果に入れる
          street.dist <- distance.points(pc, line.range2)
        }
      }else{# 灌木がないとき端点との距離のみ記録する
        street.dist = distance.points(pc, line.range2)
      }
      
    }else{
      street.dist <-NA
    }
  }else{
    street.dist <-NA
  }

  return(street.dist)
}
## street(距離補正なし)
cul.street <- function(lphi, pc, sh.data, ldist,
                       xsitesize = c(0,20),ysitesize = c(0,20)){
  # 直線作成
  # y = tan(lphi) * (x - pc[1]) + pc[2]
  # 直線と直線の範囲
  # 直線が水平、垂直の場合を分ける
  if(lphi %% pi == 0){
    if(pc[2] >= 0 & pc[2] <= 20){
      line.range <- data.frame(x = xsitesize, y = c(pc[2],pc[2]))
    }else{
      line.range <- data.frame(x = c(NA,NA), y = c(NA,NA))
    }
  }else if(lphi %% (pi/2) == 0){
    if(pc[1] >= 0 & pc[1] <= 20){
      line.range <- data.frame(x = c(pc[1],pc[1]), y = ysitesize)
    }else{
      line.range <- data.frame(x = c(NA,NA), y = c(NA,NA))
    }
  }else{
    line.range <- length.line.in.range(pc[2] - pc[1] * tan(lphi), tan(lphi))
  }
  ## phiの値でline.ragenのどの値が、線分のPCと逆側の端点かを判定する
  line.range2 <- c(NA,NA)
  if(sum(!is.na(line.range)) != 0){
    if(lphi >= pi/2 | lphi <= -pi/2){
      if(pc[1] >= line.range[1,1]){
        line.range2 <- line.range[1,]
      }
    }else{
      if(pc[1] <= line.range[2,1]){
        line.range2 <- line.range[2,]
      }
    }
  }
  
  if(!is.na(sum(line.range2))){
    if(distance.points(pc, line.range2) >= ldist){
      
      if(nrow(sh.data) !=0){
        # 直線と灌木の交点チェック
        data.inout <- ellipse.line.cross(pc[1], pc[2],lphi,
                                         sh.data$alpha, sh.data$beta, 
                                         sh.data$a, sh.data$b, sh.data$theta)
        # 交差しているものがあるかどうか
        if(sum(data.inout) != 0){ # あるならこちら
          data.in <- sh.data[data.inout,]
          crosspoints <- ellipse.line.cross.point(pc, lphi, data.in)
          # 個別streetデータ格納先
          streets <- rep(NA, length = nrow(crosspoints) + 1)
          for(i_st in 1:(nrow(crosspoints) + 1)){
            if(i_st == 1){# 直線上の最もPCに近い灌木との交点は、PCとの距離をstreetとする
              streets[i_st] <- distance.points(pc, crosspoints[i_st,c("x1","y1")])
            }else if(i_st == (nrow(crosspoints) + 1)){# 直線上のPCから最も遠い灌木との交点は、線分の端点との距離をstreetとする
              # x座標にて、PCから遠い方を線分のPC逆側の端点として、灌木との交点との距離を算出する。
              streets[i_st] <- distance.points(crosspoints[i_st - 1,c("x2","y2")], line.range2)
            }else{# 灌木間の距離を測定しstreetとする
              streets[i_st] <- distance.points(crosspoints[i_st - 1,c("x2","y2")],
                                               crosspoints[i_st,c("x1","y1")])
            }
            
          }
          street.dist <- sum(streets)
        }else{ # 交差する灌木がない場合、線分の長さを結果に入れる
          street.dist <- distance.points(pc, line.range2)
        }
      }else{# 灌木がないとき端点との距離のみ記録する
        street.dist = distance.points(pc, line.range2)
      }
      
    }else{
      street.dist <-NA
    }
  }else{
    street.dist <-NA
  }
  
  return(street.dist)
}

## Hd
# 必要データ
  # 灌木データ（データフレーム）
  # PC座標
  # 角度範囲（ベクトル）
cul.hd <- function(sh.data, pcx, pcy, ang){
  
  sh.h <- max.z.ellipse.line(sh.data,pcx, pcy, ang)
  sh.d <- distance.points(mapply(rep,c(pcx, pcy),nrow(sh.data)),sh.data[,c("alpha","beta")])
  hd.each <- correction.distance(sh.h,sh.d)
  hd <-sum(hd.each) 
  return(hd)
}

## lambda'
cul.lambda.dist <- function(sh.data, pcx, pcy, wd, area){
  sh.data$lphi.p <- wd - sh.data$theta
  b <- 2 * sqrt(sh.data$a^2 * (sin(sh.data$lphi.p))^2 + 
                  sh.data$b^2 * (cos(sh.data$lphi.p))^2)
  h <- sh.data$c
  
  # 分子
  dist <- distance.points(mapply(rep,c(pcx, pcy),nrow(sh.data)), 
                          sh.data[,c("alpha","beta")])
  lambda.allarea <- correction.distance(b * h, dist)
  # 最終計算
  output <- sum(lambda.allarea) / area
  
  return(output)
}

## lambda
cul.lambda <- function(sh.data, wd, area){
  sh.data$lphi.p <- wd - sh.data$theta
  b <- 2 * sqrt(sh.data$a^2 * (sin(sh.data$lphi.p))^2 + 
                  sh.data$b^2 * (cos(sh.data$lphi.p))^2)
  h <- sh.data$c
  
  # 分子
  lambda.allarea <- b * h
  # 最終計算
  output <- sum(lambda.allarea) / area
  
  return(output)
}

## モンテカルロ法による領域のcover, height
# %表記
cul.veg <- function(dist, pc, lphi,sh.data ,
                          xrange = c(0,20),yrange = c(0,20),nsample = 100000){
  # 点を生成（x, y座標を0-20の間で生成、一様乱数）
  x <- runif(nsample,xrange[1], xrange[2])
  y <- runif(nsample,yrange[1], yrange[2])
  
  p <- createEmptyDf( nsample, 6, c("x","y","line","dist","inout","shrub") )
  p$x <- x
  p$y <- y
  # チェック
  # plot(x,y,xlim = c(-2,22),ylim = c(-2,22))
  # 点が以下の条件に当てはまるか判定
  # 2直線の間にある
  p$line <- point.line.in(p[,c("x","y")], pc[1], pc[2], lphi[1], lphi[2])
  # 距離範囲の間にある
  p$dist <- (p$x - pc[1])^2 + (p$y - pc[2])^2 <= dist^2
  p$inout <- p$line & p$dist
  
  # 灌木内にある
  data.p <- round.robin.data(p,sh.data)

  data.p$shrub <- point.in.ellipse(data.p[,c("x","y"),],data.p$alpha,data.p$beta,
                                   data.p$a,data.p$b,data.p$theta)
  
  # cover
  cover <- sum(data.p$shrub) / sum(p$inout) * 100
  
  # height
  data.h <- round.robin.data(data.p[data.p$shrub,],sh.data)
  data.h$h <- cul.z.ellipse(data.h[,c("x","y"),],data.h$alpha,data.h$beta,
                            data.h$a,data.h$b,data.h$c,data.h$theta)

  height <- mean(data.h$h[!is.nan(data.h$h)])
  
  rm(data.p,data.h)
  gc()
  gc()
  return(c(cover, height))
}

# 関数 ----------------------------------------------------------------------
## hiについて、重複を解除する
  # 同じnについて、hiが大きい方を取得する
  # 入力はnについてソート済みデータフレーム
  large.duplicated <- function(data,key,val){
    if(sum(duplicated(data[,key])) != 0){
      noduprow <- rep(NA,nrow(data))
      i <- 1
      i_same <- 1
      for (i_row in 1:(nrow(data) - 1)) {
        if(i_row > i_same){
          if(data[i_row,key] != data[i_row + 1,key]){
            noduprow[i] <- i_row
            i = i + 1
          }else{
            for(i_same in i_row:(nrow(data)-1)){
              if(data[i_same,key] != data[i_same + 1,key]){
                noduprow[i]  <- c(i_row:i_same)[which.max(data[i_row:i_same,val])]
                i = i + 1
                break
              }
            }
          }
        }
      }
      noduprow <- noduprow[!is.na(noduprow)]
      output <- data[noduprow,]
    }else{
      output <- data
    }
    return(output)
  }

## 距離xで補正
  # データ、距離はそれぞれ対応するベクトルで与える
  # この関数を変えることで、距離補正関数を変えられる
  correction.distance <- function(data, dist){
    output <- data / exp(dist)
    return(output)
  }
  
## 特定の方向（風向など）に沿ったサイト領域内の点列データ作成のための、x軸に沿った点列作成
# pcはベクトルでPCの座標（1点）
# lphiは特定の方向
# このあと、回転移動、平行移動をおこなうことで、特定の方向に沿った領域内の点列データになる
# 範囲の判定も行っており、特定の方向の直線がサイト範囲にない場合はNAを返す
  make.xline.inrange <- function(pc,lphi,ldist,xsitesize = c(0,20),ysitesize = c(0,20),septime = 1000){
    ### x軸上での点列データの作成
    byline <- (xsitesize[2] - xsitesize[1]) * sqrt(2) / septime # 直線を示す点列の点間距離d
    
    ## 直線のサイト内範囲での端点
    # 直線が水平または垂直の場合は、PCの位置によってサイト範囲と交差するかどうか判定する
    if(lphi %% pi == 0){
      if(pc[2] >= 0 & pc[2] <= 20){
        line.range <- data.frame(x = xsitesize, y = c(pc[2],pc[2]))
      }else{
        line.range <- data.frame(x = c(NA,NA), y = c(NA,NA))
      }
    }else if(lphi %% (pi/2) == 0){
      if(pc[1] >= 0 & pc[1] <= 20){
        line.range <- data.frame(x = c(pc[1],pc[1]), y = ysitesize)
      }else{
        line.range <- data.frame(x = c(NA,NA), y = c(NA,NA))
      }
    }else{
      line.range <- length.line.in.range(pc[2] - pc[1] * tan(lphi), tan(lphi))
      # length.line.in.rangeはサイト範囲と直線が交点を持たない場合、NAの2×2の行列を返す
    }
    ## phiの値でline.ragenのどの値が、線分のPCと逆側の端点かを判定する
    line.range2 <- c(NA,NA)
    if(sum(!is.na(line.range)) != 0){
      if(lphi > pi/2 | lphi < -pi/2){
        if(pc[1] >= line.range[1,1]){
          line.range2 <- line.range[1,]
        }
      }else if(lphi == pi/2){
        if(pc[2] <= ysitesize[2]){
          line.range2 <- line.range[2,]
        }
      }else if(lphi == -pi/2){
        if(pc[2] >= ysitesize[1]){
          line.range2 <- line.range[1,]
        }
      }else{
        if(pc[1] <= line.range[2,1]){
          line.range2 <- line.range[2,]
        }
      }
    }
    
    if(!is.na(sum(line.range2))){
      if(distance.points(pc, line.range2) >= ldist){
        # 求める直線の長さを算出
        lenline <- distance.points(pc,line.range2 )
        # x軸上での求める直線のx座標
        lx <- seq(0,lenline,by = byline)
        
        # 直線データ（x軸上）をデータフレーム化
        l_xaxis <- as.data.frame(cbind(lx,rep(0,length(lx)),1:length(lx)))
        colnames(l_xaxis) <- c("lp_x","lp_y","ln")
      }else{
        l_xaxis <- NA
      }
    }else{
      l_xaxis <- NA
    }
    return(l_xaxis)
  }



## モンテカルロ法による領域の面積計算
# 必要データ
  # dist：値、 pc, lphi：ベクトル
  range.area.monte.carl <- function(dist, pc, lphi, xrange = c(0,20),yrange = c(0,20),nsample = 100000){
    # 点を生成（x, y座標を0-20の間で生成、一様乱数）
    x <- runif(nsample,xrange[1], xrange[2])
    y <- runif(nsample,yrange[1], yrange[2])
    
    p <- createEmptyDf( nsample, 5, c("x","y","line","dist","inout") )
    p$x <- x
    p$y <- y
    # チェック
    # plot(x,y,xlim = c(-2,22),ylim = c(-2,22))
    # 点が以下の条件に当てはまるか判定
      # 2直線の間にある
      p$line <- point.line.in(p[,c("x","y")], pc[1], pc[2], lphi[1], lphi[2])
      # 距離範囲の間にある
      p$dist <- (p$x - pc[1])^2 + (p$y - pc[2])^2 <= dist^2
    
    p$inout <- p$line & p$dist
    
    # 面積計算
    h <- xrange[2] - xrange[1] # サイト領域の横長さ
    v <- yrange[2] - yrange[1] # サイト領域の縦長さ
    # 面積
    output <- h * v * sum(p$inout) / nsample
    
    return(output)
  }
  
## 特定の範囲（距離・方位角）に含まれる灌木の抽出
# 入力にすでにある距離範囲で切った灌木のデータが必要
  extract.shrub.range <- function(range.dist.sh.data, range.angle, pc){
    # 範囲
    temp.range <- range.angle
    # 境界線(l1, l2)(ただし、それぞれの角度theta_l1 < theta_l2)の間に中心がある
    sh.angle.center <- point.line.in(range.dist.sh.data[,c("alpha","beta")],
                                     pc[1],pc[2],temp.range[1], temp.range[2])
    
    # 境界線と灌木が交点を持つ。
    sh.angle.cross1 <- ellipse.line.cross(pc[1],pc[2],
                                          temp.range[1], 
                                          range.dist.sh.data$alpha,
                                          range.dist.sh.data$beta,
                                          range.dist.sh.data$a,
                                          range.dist.sh.data$b,
                                          range.dist.sh.data$theta)
    sh.angle.cross2 <- ellipse.line.cross(pc[1],pc[2],
                                          temp.range[2], 
                                          range.dist.sh.data$alpha,
                                          range.dist.sh.data$beta,
                                          range.dist.sh.data$a,
                                          range.dist.sh.data$b,
                                          range.dist.sh.data$theta)
    # l1, l2どちらかと交点を持てば良い
    sh.angle.cross <- sh.angle.cross1 | sh.angle.cross2
    ## 範囲内に中心がある or 境界線と灌木が交点を持つ灌木を抽出
    range.dist.sh.data$acent <- 0
    range.dist.sh.data$acrss <- 0
    range.dist.sh.data$acent[sh.angle.center] <- 1
    range.dist.sh.data$acrss[sh.angle.cross1] <- 1
    range.dist.sh.data$acrss[sh.angle.cross2] <- 2
    temp.WsiteD.a.range <- range.dist.sh.data[sh.angle.center | sh.angle.cross,]
    
    return(temp.WsiteD.a.range)
  }
  
## ベクトル内で特定の位置iより後ろで最初に0を超える場所を取得する
# どこが0を超えるか知りたいので、iを足して元のベクトルでの位置を返す
  which.over0.afteri.h <- function(i,vec ){
    n <- length(vec)
    output <- which(vec[i:n] > 0)[1]
    if(is.na(output)){
      output = NA
    }else{
      output = i + output - 1
    }
    return(output)
    
  }
  
## ベクトル内で特定の位置iより後ろで最初に0を超える場所を取得する
# 距離がほしいので、iからの要素数を返す
  which.over0.afteri.d <- function(i,vec ){
    n <- length(vec)
    output <- which(vec[i:n] > 0)[1]
    if(is.na(output)){
      output = NA
    }else{
      output = output - 1
    }
    return(output)
    
  }

## 風向風速のデータについて風向を範囲で拡張したデータを作成する
  expand.wd.range <- function(range1, range2,byang){
    output <- seq(range1,range2,by = byang)
    return(output)
  }

## 等しい風速のデータを拾ってくる
  which.same.wd <- function(wd,vec){
    output <- which(wd == vec)[1]
    return(output)
  }
