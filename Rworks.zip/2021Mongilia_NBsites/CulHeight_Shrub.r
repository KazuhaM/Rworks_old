
# library -----------------------------------------------------------------

# library(sp)
# library(tcltk2)
# # library("fmsb")
# library("RColorBrewer")
# library(plotrix)

library(tcltk2)
library(tidyverse)
library(furrr)
# plan(multisession)


# 共通 --------------------------------------------------------------------
path <- "D:/OneDrive - g.ecc.u-tokyo.ac.jp/LEP/2020/00working/1301MongoliaAnalysis8/ShrubDistribution"
# path <- "E:/Clouds/OneDrive - g.ecc.u-tokyo.ac.jp/LEP/2020/00working/1301MongoliaAnalysis8/ShrubDistribution"

setwd(path)

WsiteD <- read.csv("WsiteShrubDistribution.csv",header = T)

WsiteD$Site <- as.factor(WsiteD$Site)
site_name <- as.factor(WsiteD$Site)
site_name <- levels(site_name)


# 高さ算出 --------------------------------------------------------------------
# サイト方位
topsite <- c()
for (i in 1:length(site_name)) {
  topsite[i] <- which(WsiteD$Site==site_name[i])[1]
}
sitedir <- WsiteD$SiteDir.E0_left.[topsite]

# 必要データ抜き出し
WsiteD2 <- data.frame(
  site = WsiteD$Site,
  gps = WsiteD$GPS,
  alpha = WsiteD$x,
  beta = WsiteD$y,
  a = WsiteD$long_axis / 2,
  b = WsiteD$short_axis / 2,
  c = WsiteD$height,
  theta = WsiteD$shrub_dir.E0_left. * pi / 180
)
dataname <- c("gps","alpha","beta","a","b","c","theta") # site名を除いた列名

# グリッドポイントの座標行列を生成
p_grid_x <- seq(0,20,by = 0.01)
p_grid_y <- seq(0,20,by = 0.01)

# 円周上の点の座標を出すための、-180~180の角度
pori_sm <- 100
base_x <- seq(-pi, pi, length=pori_sm)

# 計算を分割する分割数
sepcul <- 23
p_grid_y_sep <- matrix(p_grid_y,ncol = sepcul)　# データをsepcul個に分割している

# 本体
for (i in 2:length(site_name)) {
  # 結果まとめデータフレーム
  result.summary <- data.frame(matrix(rep(NA, 5), nrow=1))[numeric(0), ]
  result.colnames <- c("x","y","gps","height","inout")
  colnames(result.summary) <- result.colnames
  
  for(j_sep in 1:sepcul){
    # x-yの総当りデータフレーム作成
    # データをsepcul個に分割している
    p_grid_y2<- as.vector(mapply(rep,p_grid_y_sep[,j_sep],length(p_grid_x)))
    point.coord <- as.data.frame(cbind(p_grid_x,p_grid_y2))
    colnames(point.coord) <- c("x","y")
    
    # 該当サイト-イベントのデータを抽出
    temp_WsiteD <- WsiteD2[WsiteD2$site == site_name[i],c(dataname)]
    temp_WsiteD3 <- temp_WsiteD
    # 計算範囲の灌木のみ抽出
    temp_WsiteD <- 
      temp_WsiteD[p_grid_y_sep[1,j_sep] - temp_WsiteD$a <= temp_WsiteD$beta &
                  temp_WsiteD$beta <= p_grid_y_sep[nrow(p_grid_y_sep),j_sep] + temp_WsiteD$a ,] 
    
    
    ### 結果確認用プロット準備 
    ## 楕円ポリゴンの作成 
    shrb_px <- data.frame(matrix(rep(NA, pori_sm), nrow=1))[numeric(0), ]
    shrb_py <- data.frame(matrix(rep(NA, pori_sm), nrow=1))[numeric(0), ]
    
    # 楕円周上の点の座標を取得
    for(j in 1:nrow(temp_WsiteD)){
      # 長軸（半分）
      t_a <- temp_WsiteD$a[j]
      # 短軸（半分）
      t_b <- temp_WsiteD$b[j]
      # 回転角
      t_theta <- temp_WsiteD$theta[j]
      # 中心のx座標
      t_cenx <- temp_WsiteD$alpha[j]
      # 中心のy座標
      t_ceny <- temp_WsiteD$beta[j]
      
      # 楕円周上の点の座標
      t_x <- t_a * cos(base_x) * cos(t_theta) - t_b * sin(base_x) * sin(t_theta) + t_cenx
      t_y <- t_a * cos(base_x) * sin(t_theta) + t_b * sin(base_x) * cos(t_theta) + t_ceny
      
      t_x <- data.frame(rbind(t_x))
      row.names(t_x) <- j
      t_y <- data.frame(rbind(t_y))
      row.names(t_y) <- j
      
      shrb_px <- rbind(shrb_px,t_x)
      shrb_py <- rbind(shrb_py,t_y)
    }
    
    ### 群落高計算
    # 点の座標を灌木数分用意する
    temp.point.coord <- as.data.frame(mapply(rep,point.coord,nrow(temp_WsiteD)))
    # 灌木データを点の数分用意する
    temp_WsiteD2 <- as.data.frame(mapply(rep, temp_WsiteD,nrow(point.coord)))
    temp_WsiteD2 <- temp_WsiteD2[order(temp_WsiteD2$gps),] #灌木の順番を整理
   
    # 計算用データをまとめる
    test.data <- cbind(temp.point.coord,temp_WsiteD2)
    row.names(test.data) <- NULL
    
    # 格子点ごとの高さを計算する
    test.result <- future_pmap_dfr(test.data,coordiZsummary, .progress = T)
    test.result <- test.result[test.result$inout == 1,]
    
    # 結果をまとめに統合
    result.summary <- rbind(result.summary,test.result)

    # マーカー
    print(paste(j_sep,"/",sepcul,"まで終了",sep ="" ))
  }
  ### 結果のプロット
  result.summary$col <- result.summary$height / max(temp_WsiteD3$c) # 高さをグレースケールで
  # プロット
  # par(mar = c(1,1,1,1),xpd=F,family = family_serif)
  
  # 枠
  plot.new()
  plot.window(xlim=c(-2, 22), ylim=c(-2, 22)) 
  for (j in 1:4) {
    axis(side = j, at=seq(0, 20, by = 5))
  }
  for (j in 0:20) {
    segments(j, 0, j, 20)
    segments(0, j, 20, j)
  }
  for (j in 0:4) {
    abline(h = j*5, lty=3)
    abline(v = j*5, lty=3)
  }
  
  # 高さの点をプロット
  points(result.summary$x ,result.summary$y,xlim = c(-2,22),ylim = c(-2,22),
       col = gray(result.summary$col),bg = gray(result.summary$col),pch=21)
  
  # 灌木のポリゴンプロット
  for(i_shrub in 1:nrow(shrb_px)){
    polygon(shrb_px[i_shrub,] ,shrb_py[i_shrub,])
  }
  arrows(-1.5, 21.5, cos(sitedir[i] * pi / 180) - 1.5,
         sin(sitedir[i] * pi / 180) + 21.5 ,angle = 15, length = 0.15)
  text(1.3* cos(-sitedir[i] * pi / 180) - 1.5,
       1.3 * sin(sitedir[i] * pi / 180) + 21.5, "N")
  for(j in 1:10){
    rect(4+j, -1, 5+j, -0.5,border = TRUE,col=gray(j/10))
  }
  text(5,-1.5,0)
  text(15,-1.5,max(temp_WsiteD3$c))
  
  # 結果出力
  dev.copy(cairo_pdf, file=paste("EllipsoidHeight/Shrubheightplot",site_name[i],".pdf",sep=""), width = 10, height = 10)
  dev.off()
  write.csv(result.summary, paste("EllipsoidHeight/ellipsoid_height",site_name[i],".csv", sep = ""),row.names=FALSE)


  # マーカー
  print(paste(i,"/",length(site_name),"まで終了",sep ="" ))
}


# Functions ---------------------------------------------------------------

# ある点(x,y)における回転した楕円の左辺を求める
# 楕円は原点を中心とする長軸2a, 短軸2bの楕円をtheta(rad)だけ回転し、(alpha, beta)だけ平行移動したもの
# 楕円の円周上に点(x,y)が存在するなら=0
rotateellipse <- function(x, y, alpha, beta, a, b, theta){
  # 平行移動
  hX <- x - alpha
  hY <- y - beta
  
  rX <- hX * cos(-theta) - hY * sin(-theta)
  rY <- hX * sin(-theta) + hY * cos(-theta)
  # 楕円の回転移動に代入
  output <- rX^2 / a^2 + rY ^2 / b^2 - 1
  
  # output <- X^2 * (b^2 * (cos(theta))^2 + a^2 * (sin(theta))^2) + 
  #             Y^2 * (b^2 * (sin(theta))^2 + a^2 * (cos(theta))^2) +
  #               2 * X *Y * sin(theta) * cos(theta) * (b^2 *  - a^2) -
  #                 a^2 * b^2
  # 出力
  return(output)
}

# 回転した楕円楕円体におけるあるx,yのときのzの値を求める
# 楕円体はx^2 / a^2 + y^2 / b^2 + z^2 / c^2 = 1をz軸を回転軸にしてtheta回転移動（rad）と
# xy平面上で(alpha, beta)平行移動したもの
# 当該楕円体のxy平面上の楕円の方程式の左辺（=0となるとき)を要求
coodiZellipsoid <- function(a, b, c, fxy){
  # 楕円体の座標算出
  # z <- c * sqrt(-fxy) / (a * b)
  z <- c * sqrt(-fxy)
  # 出力
  return(z)
}

coordiZsummary <- function(x, y, gps, alpha, beta, a, b, c, theta){
  # 結果データフレーム
  result <- data.frame(matrix(rep(NA, 5), nrow=1))[numeric(0), ]
  result.colnames <- c("x","y","gps","height","inout")
  colnames(result) <- result.colnames
  
  fxy <- rotateellipse(x, y, alpha, beta, a, b, theta)
  
  if(fxy <= 0){
    # 楕円体の座標算出
    z <- coodiZellipsoid(a, b, c, fxy)
    
    result <- rbind(result,c(x,y,gps,z,1))
    colnames(result) <- result.colnames
  }else{
    result <- rbind(result,c(x,y,0,0,0))
    colnames(result) <- result.colnames
  }
  result <- as.vector(result)
  return(result)
}

# 高さ分布(グリッドベース) --------------------------------------------------------------------
# 結果データフレーム
h.dist.summary <- data.frame(matrix(rep(NA,4),nrow =1))[0,]
h.dist.colname <- c("Site","AveHeight","sd","n")
colnames(h.dist.summary) <- h.dist.colname
# 計算
for (i_site in site_name) {
  h.dist <- read.csv(paste("EllipsoidHeight/ellipsoid_height",i_site,".csv", sep = ""))
  hist(h.dist$height,main = "",xlab = "grid height (m)")
  abline(v = mean(h.dist$height),col = 2)
  h.dist.summary <- rbind(h.dist.summary,c(i_site,mean(h.dist$height),sd(h.dist$height),nrow(h.dist)))
  
  # 結果出力
  dev.copy(cairo_pdf, file=paste("EllipsoidHeight/height_hist_",i_site,".pdf",sep=""), width = 10, height = 10)
  dev.off()
}
colnames(h.dist.summary) <- h.dist.colname
write.csv(h.dist.summary, paste("EllipsoidHeight/height_summary.csv", sep = ""),row.names=FALSE)

# 高さ分布(個体ベース) --------------------------------------------------------------------
h.dist.ind.summary <- data.frame(matrix(rep(NA,4),nrow =1))[0,]
h.dist.colname <- c("Site","AveHeight","sd","n")
colnames(h.dist.ind.summary) <- h.dist.colname

for (i_site in site_name) {
  h.dist.ind <- WsiteD[WsiteD$Site == i_site,]
  
  # 各灌木の、サイト全体の灌木被度に対する個体の被度を、その個体の高さの頻度として、平均を算出する
  # つまり、灌木全体に対する当該個体の占める面積割合によって灌木の高さの確率分布を考え、平均する
  h.area <- (h.dist.ind$long_axis/2) * (h.dist.ind$short_axis /2) * pi
  h.area <- h.area / sum(h.area)
  weighting.h <- h.dist.ind$height * h.area
  
  hist(h.dist.ind$height,main = "",xlab = "shrub individuals' height (m)")
  abline(v = sum(weighting.h),col = 2)
  h.dist.ind.summary <- rbind(h.dist.ind.summary,c(i_site,sum(weighting.h),sd(h.dist.ind$height),nrow(h.dist.ind)))
  
  # 結果出力
  dev.copy(cairo_pdf, file=paste("EllipsoidHeight/Ind_height_hist_",i_site,".pdf",sep=""), width = 10, height = 10)
  dev.off()
}
colnames(h.dist.ind.summary) <- h.dist.colname
write.csv(h.dist.ind.summary, paste("EllipsoidHeight/Ind_height_summary.csv", sep = ""),row.names=FALSE)

