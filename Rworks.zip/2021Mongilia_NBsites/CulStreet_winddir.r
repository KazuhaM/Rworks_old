
# library -----------------------------------------------------------------

library(sp)
library(tcltk2)
# library("fmsb")
library("RColorBrewer")
library(plotrix)
# 内外の判定 0 : 領域外の点 1 : 領域内の点 2 : 境界上の点(辺) 3 :境界上の点(頂点)
# res <- point.in.polygon(x, y, pol.x, pol.y)


# main --------------------------------------------------------------------
path <- "D:/OneDrive - g.ecc.u-tokyo.ac.jp/LEP/2020/00working/1301MongoliaAnalysis8/ShrubDistribution"
setwd(path)

WsiteD <- read.csv("WsiteShrubDistribution.csv",header = T)
# WsiteD_index <- setdiff(colnames(WsiteD), c("SiteDir.E0_left.","shrub_dir.E0_left."))
# WsiteD <- WsiteD[WsiteD_index]
site_name <- as.factor(WsiteD$Site)
site_name <- levels(site_name)

# イベント風向(N0right)
eventwd <- c(245.6537782, # W2-3_4
             272.0940444, # W2-3_5
             63.42984944, # W2-3_6
             276.8279183, # W2-5_1
             291.2269448, # W3-3_1
             242.2881938) # W3-4_1
eventname <- c("W2-3_4","W2-3_5","W2-3_6","W2-5_1","W3-3_1","W3-4_1")
i_ev <- 6 #site-event wd number
# site_name: "W2-3" "W2-5" "W3-3" "W3-4"
i <- 4 # site number


# グリッドポイントの座標行列を生成
p_grid_x <- 0:20
p_grid_y <- 0:20

# 原点からseptime分割の各方位に対して伸ばした線分のx, y座標
# 方位の分割数はseptimeで定義。sepcountsは線分の分割数
# 線分の長さはほぼ対角線と等しい
# このとき、線分を構成する点間の距離は約2.83cm (sqrt(2)/50 m)
septime <- 1
sepangle <- eventwd[i_ev] # イベント風向
sepcounts <- 1002

# 円周上の点の座標を出すための、-180~180の角度
pori_sm <- 100
base_x <- seq(-pi, pi, length=pori_sm)


# for (i in 1:length(site_name)) {
  # 該当サイト-イベントのデータを抽出
  temp_WsiteD <- WsiteD[WsiteD$Site == site_name[i],]
  
  ### streetの計算
  # street計算時の直線の座標取得
  # basiangleにはサイト上E0leftのサイト方位を入れる
  i_baseangle <- temp_WsiteD$SiteDir.E0_left.[1]
  lineang <- 360 - (sepangle - i_baseangle ) # 30方位(0<180)についてE0leftでsite angleを考慮表記
  linepointx <- flinepointx_wd(sepcounts,sepangle,i_baseangle)
  linepointy <- flinepointy_wd(sepcounts,sepangle,i_baseangle)
  
  ## 楕円ポリゴンの作成 
  shrb_px <- data.frame(matrix(rep(NA, pori_sm), nrow=1))[numeric(0), ]
  shrb_py <- data.frame(matrix(rep(NA, pori_sm), nrow=1))[numeric(0), ]
  
  # 楕円周上の点の座標を取得
  for(j in 1:nrow(temp_WsiteD)){
    # 長軸（半分）
    t_a <- temp_WsiteD$long_axis[j]/2
    # 短軸（半分）
    t_b <- temp_WsiteD$short_axis[j]/2
    # 回転角
    t_theta <- temp_WsiteD$shrub_dir.E0_left.[j] * pi / 180
    # 中心のx座標
    t_cenx <- temp_WsiteD$x[j]
    # 中心のy座標
    t_ceny <- temp_WsiteD$y[j]
    
    # 楕円周上の点の座標
    t_x <- t_a * cos(base_x) * cos(t_theta) - t_b * sin(base_x) * sin(t_theta) + t_cenx
    t_y <- t_a * cos(base_x) * sin(t_theta) + t_b * sin(base_x) * cos(t_theta) + t_ceny
    
    t_x <- data.frame(rbind(t_x))
    row.names(t_x) <- j
    t_y <- data.frame(rbind(t_y))
    row.names(t_y) <- j
    
    shrb_px <- rbind(shrb_px,t_x)
    shrb_py <- rbind(shrb_py,t_y)
  }
  
  # streetを計算
  # 結果格納用データベースresult.shrb.distrに行を追加
  result.shrb.distr <- data.frame(matrix(rep(NA, 5), nrow=1))[numeric(0), ]
  df.colnames <- c("grid_x","grid_y","angle", "no", "length")
  colnames(result.shrb.distr) <-df.colnames
  pb <- txtProgressBar(min = 1, max = 21, style = 3)
  for (xi in 1:21) {
    for (yi in 1:21) {
      i_linepointx <- linepointx + p_grid_x[xi]
      i_linepointy <- linepointy + p_grid_y[yi]
      
        i_no <- 1
        # そもそも20mや0mを超えている部分は不要
        i_linepointx.t <- i_linepointx <= 20 & i_linepointx >= 0
        i_linepointy.t <- i_linepointy <= 20 & i_linepointy >= 0
        
        i_linepointx2 <- i_linepointx[i_linepointx.t & i_linepointy.t]
        i_linepointy2 <- i_linepointy[i_linepointx.t & i_linepointy.t]
        if(length(i_linepointx2) <= 1){
          # そもそもサイト内に直線がない場合20 * sqrt(2)mを入れて次に進む
          temp.val <- 20 * sqrt(2)
          result.shrb.distr <- rbind(result.shrb.distr,c(xi,yi,sepangle,i_no,temp.val))
          i_no <- i_no + 1
        }else{
          res <- list()
          for (ishrb in 1:nrow(temp_WsiteD)) {
            # 直線上の点でポリゴンの内外をチェック。0のときのみポリゴン外
            res[[ishrb]] <- point.in.polygon(i_linepointx2, i_linepointy2, 
                                             shrb_px[ishrb,], shrb_py[ishrb,])
          }
          res2 <- sapply(res,sum)
          if (sum(res2) == 0) {
            # 交点がないときは線分の長さを入れる
            temp.val <- (i_linepointx2[length(i_linepointx2)] - i_linepointx2[1]) / 
              cos(lineang * pi / 180)
            result.shrb.distr <- rbind(result.shrb.distr,c(xi,yi,sepangle,i_no,temp.val))
            i_no <- i_no + 1
          }else{
            for(i_res in 1:length(res2)){
              if(res2[i_res] != 0){
                startflag <- TRUE
                endflag <- FALSE
                for (i_line in 1:length(res[[i_res]])) {
                  if (res[[i_res]][i_line] == 0 & startflag) {
                    i_start <- i_line
                    startflag <- FALSE
                    endflag <- TRUE
                  }else if(res[[i_res]][i_line] != 0 & endflag){
                    i_end <- i_line
                    
                    temp.val <- (i_linepointx2[i_end] - i_linepointx2[i_start]) / 
                      cos(lineang * pi / 180)
                    result.shrb.distr <- rbind(result.shrb.distr,c(xi,yi,sepangle,i_no,temp.val))
                    i_no <- i_no + 1
                    
                    startflag <- TRUE
                    endflag <- FALSE
                  }
                }
              }
            }
          }
        }
      setTxtProgressBar(pb, xi) 
    }
  }
  # 結果出力
  colnames(result.shrb.distr) <-df.colnames
  result.shrb.distr$angle <- as.factor(result.shrb.distr$angle)
  result.shrb2 <- tapply(result.shrb.distr$length,result.shrb.distr$angle,mean)
  result.shrb.distr$wdstreet[1] <- result.shrb2
  write.csv(result.shrb.distr, paste("Street_Lambda/wd",eventname[i_ev],"_shdist.csv", sep = ""),row.names=FALSE)
  # write.csv(as.data.frame(result.shrb2), paste("Street_Lambda/wd",site_name[i],"_avelen.csv", sep = ""),row.names=TRUE)
  
  ### ラムダ
  ## ラムダの計算
  
  # 計算結果格納
  result.l.temp <- data.frame(matrix(rep(NA, 3), nrow=1))[numeric(0), ]
  colnames(result.l.temp) <- c("site","wind.dir.E0left","lateralC")
  for(i_waz in lineang ){
    # 各楕円を横向きであるとしたとき、ある方角i_wazから見たときの
    # 楕円の幅（接線y = x * tan(i_waz) + cの間隔）を求める。
    # i_wazから楕円の回転角度を引いて、横向きの楕円に対するi_waz（ここではtheta）を計算する
    temp_WsiteD$thetaC <- i_waz - temp_WsiteD$shrub_dir.E0_left.
    temp_WsiteD$thetaC <- temp_WsiteD$thetaC * pi / 180
    
    shortax <- temp_WsiteD$short_axis /2
    longax <- temp_WsiteD$long_axis /2
    
    # 特定の角度thetaについて、楕円の幅は2 * sqrt(b^2 * {cos(theta)}^2 + a^2 * {sin(theta)}^2)
    temp_WsiteD$width <- 2*sqrt((shortax * cos(temp_WsiteD$thetaC))^2 +
                                  (longax * sin(temp_WsiteD$thetaC))^2)
    temp_WsiteD$LS <- temp_WsiteD$width * temp_WsiteD$height 
    result.l.temp <- rbind(result.l.temp,c(site_name[i], i_waz, sum(temp_WsiteD$LS)/20^2))
  }
  colnames(result.l.temp) <- c("site","line.dir.E0left","lateralC")
  result.l.temp$line.dir.E0left <- as.factor(result.l.temp$line.dir.E0left)
  result.l.temp$lateralC <- as.numeric(result.l.temp$lateralC)
  
  # 結果出力
  write.csv(result.l.temp, paste("Street_Lambda/wd",eventname[i_ev],"_lambda.csv", sep = ""),row.names=FALSE)
  
  
  # マーカー
  print(paste(i,"/",length(site_name),"まで終了",sep ="" ))



# Functions ---------------------------------------------------------------

flinepointx_wd <- function(count,evwd,abaseangle){
  # evwdはN0rightのイベントごとの風向
  
  output <- data.frame(matrix(NA, nrow=2*count-1, ncol = 1))
  colnames(output) <- evwd # 出力データフレームの列名はN0rightの方位角
  reprang <- 360 - (evwd - abaseangle ) # E0leftで表記
  temp.line <- seq(0,length = count, by = sqrt(2)*cos(reprang * pi / 180) / 50)
  temp.line <- c(rev(-temp.line),temp.line[2:length(temp.line)])
  
  output[,1] <- temp.line
  return(output)
}
flinepointy_wd <- function(count,evwd,abaseangle){
  # evwdはN0rightのイベントごとの風向
  
  output <- data.frame(matrix(NA, nrow=2*count-1, ncol = 1))
  colnames(output) <- evwd # 出力データフレームの列名はN0rightの方位角
  reprang <- 360 - (evwd - abaseangle ) # E0leftで表記
  
  temp.line <- seq(0,length = count, by = sqrt(2)*sin(reprang * pi / 180) / 50)
  temp.line <- c(rev(-temp.line),temp.line[2:length(temp.line)])
  
  output[,1] <- temp.line
  return(output)
}

