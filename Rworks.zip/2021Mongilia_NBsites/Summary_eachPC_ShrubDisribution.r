# library -----------------------------------------------------------------
library(tcltk2) # プログレスバー
library(tictoc) # 処理時間計測
library(tidyverse)
library(furrr)
plan(multisession, workers = 7)
options(scipen=5)


# 関数ファイルの読み込み -------------------------------------------------------------
cordpath <- "D:/Documents/Rworks/2021Mongilia_NBsites"
setwd(cordpath)
source("Functions_eachPC_ShrubDistribution.r")
source("Models_Okin_new.r")

# データ読み込み -----------------------------------------------------------------
### working directory
path <- "D:/OneDrive - g.ecc.u-tokyo.ac.jp/LEP/2020/00working/1301MongoliaAnalysis8/EachPC_EachTime/Data"
setwd(path)

### 灌木情報
WsiteD <- read.csv("WsiteShrubDistribution.csv",header = T)
# 灌木の長軸、短軸をa, bに変換する
WsiteD$a <- WsiteD$long_axis / 2
WsiteD$b <- WsiteD$short_axis / 2
# 灌木の回転角度をラジアン変換
WsiteD$shrub_dir.E0_left. <- WsiteD$shrub_dir.E0_left. * pi / 180
# 必要な情報再構成
WsiteD2 <- data.frame(Site = WsiteD$Site,
                      alpha = WsiteD$x , 
                      beta = WsiteD$y , 
                      a = WsiteD$a , 
                      b = WsiteD$b , 
                      c = WsiteD$height , 
                      theta = WsiteD$shrub_dir.E0_left.)

### イベント毎のPC情報（サイト情報含む）
WPCD <- read.csv("eachPC_ev.csv",header = T)

### us, sfデータ（全サイト-イベント
WusfD <- read.csv("Z0Us_MoM_60_sumdata.csv",header = T)
WusfD <- WusfD[WusfD$Event !=99,] # イベント中のデータのみ抽出
WusfD2 <- WusfD[,c("SiteID","Event","mean3WD","SF_sl_1","SF_sl_2","SF_sl_3","Us")]
## mean3WDについて
#  mean3WDはサイト方位を考慮して、サイト上E0leftにcsvの時点で修正済み（計算はxlsxファイル）
# 0.1°間隔になるように、度数法変換→四捨五入→ラジアン変換
WusfD2$mean3WD <- round(WusfD2$mean3WD * 180 / pi,digit = 1)
WusfD2$mean3WD <- WusfD2$mean3WD *pi/180



# 事前作成データ -----------------------------------------------------------------
rangeangle <- c(1,10,15,30,45,60,90) # PCからの角度範囲
rangeangle <- rangeangle * pi / 180 # ラジアン変換

# 何度刻みで角度を考えるか（度数法）
byang <- 0.1 
byang <- byang * pi / 180 # ラジアン変換
modelbyang <- byang * 5

distrate <- c(1,5,10,25,50,100) #PCからの距離範囲について、灌木平均高hの何倍を考えるか

## 出力データフレーム
final.result <- createEmptyDf(1,24,
                              c(c("rangang","wd","sf","us",
                                  "Hae","street_dist","street","Arate_line","nline","cover","height",
                                  "Hd","lambda_dist","lambda","maxS_range","S_range",
                                  "M_Okin","M_new","rangdist","site","ev","pcNo","mean.h", "ust")))[0,]

# 計算本体 --------------------------------------------------------------------
# PCごと（WPCDの一行ごと）
pb.pc <- txtProgressBar(min = 1, max = nrow(WPCD)*length(distrate), style = 3)
tic()
for(i_sitePC in 1:nrow(WPCD)){
  ### データ整形
  {
    # 該当PC情報抽出
    temp.WPCD <- WPCD[i_sitePC,]
    
    # 基本情報取得
    sitename <- temp.WPCD$SiteID
    evname <- temp.WPCD$Event
    PC.order <- temp.WPCD$PC_order
    PC.odr.name <- paste("SF_sl_",PC.order,sep="")
    PC.No <-  temp.WPCD$PC_No
    PCx <- temp.WPCD$x
    PCy <- temp.WPCD$y
    mean.h <- temp.WPCD$mean_h
    ust <- temp.WPCD$u.t
    lamb.pc <- temp.WPCD$lateralC
    
    # 灌木データ抽出　（該当サイト）
    temp.WsiteD <- WsiteD2[WsiteD2$Site == sitename,]
    row.names(temp.WsiteD) <- NULL
    
    # us, sfデータ抽出 (該当サイト・イベント)
    temp.WusfD <- WusfD2[WusfD2$SiteID == sitename & WusfD2$Event == evname,
                         c("mean3WD",PC.odr.name,"Us")]
    temp.WusfD$Us <- round(temp.WusfD$Us,2)
    
    
    dist.result <- createEmptyDf(1,19,
                                  c(c("rangang","wd","sf","us",
                                      "Hae","street_dist","street","Arate_line","nline","cover","height",
                                      "Hd","lambda_dist","lambda","maxS_range","S_range",
                                      "M_Okin","M_new","rangdist")))[0,]
  }
  
  ### あるPCからの距離範囲について、
  # pb.dist <- txtProgressBar(min = 1, max = length(distrate), style = 3)
  # tic()
  for(i_dist in distrate){　#距離範囲
    # 距離を灌木の平均高についての割合から、実際の長さに変換
    r = mean.h * i_dist
    
    ## 各指標について、ある距離範囲のとき、ありうるパターンの値を格納するデータフレームの作成
    {
      # 風向に対してある範囲について、逐次発生させた直線の情報を用いる指標
      lineIndicator <-createEmptyDf(2 * pi / byang, (1+3),
                                    colnames = c("wd","Hae","street_dist","street"))
      # 風向に対して一定の範囲について一つの値を持つ指標
      wdlev <- temp.WusfD$mean3WD # 風向の種類数
      wdlev <- unique(wdlev)
      rangeIndicator <- createEmptyDf(length(wdlev), (2+5+2),
                                      colnames = c("wd","ang_range","cover","height","Hd","lambda_dist","lambda","maxS","S"))
    }
    
    ## PCから距離i_dist * mean.hの範囲の灌木を抽出
    {
      # 中心が範囲内にある
      sh.rangecenter <- (temp.WsiteD$alpha - PCx)^2 + (temp.WsiteD$beta - PCy)^2 <= r^2
      
      # 範囲円と灌木が交点を持つ。
      sh.rangecross <- rep(NA,nrow(temp.WsiteD))
      for(i_shrub in 1:nrow(temp.WsiteD)){
        sh.rangecross[i_shrub] <- ellipse.circle.cross(PCx,PCy,r,temp.WsiteD$alpha[i_shrub],
                                                                 temp.WsiteD$beta[i_shrub],
                                                                 temp.WsiteD$a[i_shrub],
                                                                 temp.WsiteD$b[i_shrub],
                                                                 temp.WsiteD$theta[i_shrub])
      }
      # 中心が範囲内にあるか、範囲園と灌木が交点を持つかどちらかを満たすなら、考えるべき灌木
      sh.range <- sh.rangecenter | sh.rangecross
    }
    
    ## あり得る最大角度範囲に関するbyang度ごとの直線を考える
    {
      # ang.maxmin.range <- c(min(temp.WusfD$mean3WD),max(temp.WusfD$mean3WD)) - max(rangeangle)/2
      # 同じイベントであっても、頻度は低くとも割と全方位吹いていたりするようなので、
      # 360度(全周)を0.1°刻みで考える
      ang.maxmin.range <- c(-pi,pi)
      ang.range <- seq(ang.maxmin.range[1],ang.maxmin.range[2],by = byang)[-1]
    }
    
    # 考えるべき灌木がない場合は別処理
    if (sum(sh.range) != 0) {
      # 距離範囲にある灌木を抽出
      temp.WsiteD.d.range <- temp.WsiteD[sh.range,]

      
      ### line Indicatorの算出
      {
        # 風向に対してある範囲について、逐次的に発生させた直線の情報を用いる指標の算出
        
        ### furrrの使用
        # ang.rangeをそのまま使って、furrrでの処理を行う
        # 予め、すべての指標で使いうる物を集めたデータフレームを作成する
        # 灌木データについては、i_ang, 指標間で共通のため、ここで、各指標算出関数を
        # 再定義し、初期値に抽出済みの灌木データ（temp.WsiteD.d.range）を入れておく
        
        PC <- c(PCx, PCy)
        ## 関数再定義
        formals(cul.hae)$pc <- PC
        formals(cul.hae)$shrub.data <- temp.WsiteD.d.range
        formals(cul.hae)$ldist <- r
        
        formals(cul.street.dist)$pc <- PC
        formals(cul.street.dist)$sh.data <- temp.WsiteD.d.range
        formals(cul.street.dist)$ldist <- r
        
        formals(cul.street)$pc <- PC
        formals(cul.street)$sh.data <- temp.WsiteD.d.range
        formals(cul.street)$ldist <- r
        
        # 計算実行
        
        lineIndicator$wd <- ang.range

        lineIndicator$Hae <- future_map_dbl(ang.range,cul.hae,.progress = TRUE)
        lineIndicator$street_dist <- future_map_dbl(ang.range,cul.street.dist,.progress = TRUE)
        lineIndicator$street <- future_map_dbl(ang.range,cul.street,.progress = TRUE)
        # print(paste("culed of lineInd, ",
        # "dist: ",i_dist,"/",length(distrate),", pc: ",i_sitePC,"/",nrow(WPCD),sep = ""))
        
        ##### for test
        {
          # pb.linInd <- txtProgressBar(min = 1, max = length(ang.range), style = 3)
          # for(i_ang in 1:length(ang.range)){
          #   # ang.maxmin.rangeの範囲で、角度をbyangずつかえて、
          #   # それぞれの方向のHae, M_Okin, M_new, streetを算出する
          #   
          #   # 角度の記録
          #   lineIndicator$wd[i_ang] <- ang.range[i_ang]
          #   # Hea
          # lineIndicator$Hae[i_ang] <- cul.hae(ang.range[i_ang],PC,temp.WsiteD.d.range,r)
          # 
          #   # street'
          #   lineIndicator$street_dist[i_ang] <- cul.street.dist(ang.range[i_ang], c(PCx, PCy),temp.WsiteD.d.range )
          #   # street(距離補正なし) 
          #   # lineIndicator$street[i_ang] <- cul.street(ang.range[i_ang], c(PCx, PCy),temp.WsiteD.d.range )
          #   
          #   setTxtProgressBar(pb.linInd, i_ang)
          # }
          # toc()
          # print("end")
        }
      }
      
      ### model系の計算
      if(!is.na(ust)){
        # あり得るusとwdの組み合わせについてすべて予め計算しておく
        # あるus, wdのペアについて、i_rangangの幅でデータを作成
        # 全データ抽出
        all.wdus <- temp.WusfD[,c("Us","mean3WD")]
        row.names(all.wdus) <- NULL
        all.wdus <- all.wdus[all.wdus$Us >= ust, ]
        # 各wdに対する角度範囲算出
        range <- createEmptyDf(nrow(all.wdus),2,c("ar1","ar2"))
        range$ar1 <- all.wdus$mean3WD - rangeangle[length(rangeangle)]/2
        range$ar2 <- all.wdus$mean3WD + rangeangle[length(rangeangle)]/2
        # range$ar1 <- all.wdus$mean3WD - i_rangang/2
        # range$ar2 <- all.wdus$mean3WD + i_rangang/2
        
        # 各データについてwdを角度範囲に拡張
        formals(expand.wd.range)$byang <- modelbyang
        all.wd <- mapply(expand.wd.range,range$ar1,range$ar2)
        all.us <- mapply(rep, all.wdus$Us,nrow(all.wd)) # usデータもwdの拡張数分増やしておく
        all.wd.ori <- mapply(rep, all.wdus$mean3WD,nrow(all.wd)) # もともとの風向データも保持
        dim(all.wd) <- c(nrow(all.wd) * ncol (all.wd),1) # ベクトル化
        dim(all.us) <- c(nrow(all.us) * ncol (all.us),1) # ベクトル化
        dim(all.wd.ori) <- c(nrow(all.wd.ori) * ncol (all.wd.ori),1) # ベクトル化
        # us, wdの全組み合わせデータフレーム作成
        all.wdus2 <- data.frame(us = all.us, lphi = all.wd,wd = all.wd.ori) 
        # 省メモリ用処理
        rm(all.wdus,all.wd,all.us,all.wd.ori) 
        gc(reset = TRUE)
        gc(reset = TRUE)
        # lphiを-piからpiに変換
        all.wdus2$lphi <- mpi.to.pi(all.wdus2$lphi)
        # 昇順に並べ替え
        all.wdus2 <- all.wdus2[order(all.wdus2$lphi),]
        
        all.wdus2 <- all.wdus2[order(all.wdus2$us),]
        all.wdus2 <- all.wdus2[order(all.wdus2$wd),]
        
        # 重複解除
        all.wdus2 <-all.wdus2 %>% dplyr::distinct(us, lphi,.keep_all=T)
        
        # wdの値をもとにlambda_distを取得してmap計算するためのデータを作成
        formals(which.same.wd)$vec = rangeIndicator$wd
        all.dat.model <- data.frame(lphi = all.wdus2$lphi,us = all.wdus2$us,
                                    lambda =  rangeIndicator[sapply(all.wdus2$wd,which.same.wd),
                                                             "lambda_dist"])
        # 省メモリ用処理
        rm(all.wdus2) 
        gc(reset = TRUE)
        gc(reset = TRUE)
        
        
        ## model計算
        # 初期値調整
        # new用
        formals(cul.model.new)$pc <- c(PCx, PCy)
        formals(cul.model.new)$ldist <- r
        formals(cul.model.new)$shrub.data <-temp.WsiteD.d.range[,2:ncol(temp.WsiteD.d.range)]
        formals(cul.model.new)$ustr <- ust
        
        # okin用
        formals(cul.model.okin)$lambda <- lamb.pc
        formals(cul.model.okin)$pc <- c(PCx, PCy)
        formals(cul.model.okin)$ldist <- r
        formals(cul.model.okin)$aveh <- mean.h
        formals(cul.model.okin)$shrub.data <-temp.WsiteD.d.range[,2:ncol(temp.WsiteD.d.range)]
        formals(cul.model.okin)$ustr <- ust
        
        # map計算
        # tic()
        q.new.line <- future_pmap_dbl(all.dat.model,cul.model.new,.progress = TRUE)
        # toc()
        # tic()
        q.okin.line <- future_pmap_dbl(all.dat.model[,c("lphi","us")],cul.model.okin,.progress = TRUE)
        # toc()
        
        # modelの結果
        modelIndicator <- data.frame(M_Okin = q.okin.line, M_new = q.new.line)
        modelIndicator <- cbind(all.dat.model,modelIndicator)
      }else{
        modelIndicator <- NA
      }
      
      ### ある角度範囲に関する結果出力先データフレーム
      result <- createEmptyDf(1,18,
                              c("rangang","wd","sf","us",
                                "Hae","street_dist","street","Arate_line","nline","cover","height",
                                "Hd","lambda_dist","lambda","maxS_range","S_range",
                                "M_Okin","M_new"))[0,]
      
      ### 角度範囲について逐次処理
      # 風向に対する一定範囲に関する指標の算出と、実際の各時刻データに合わせたデータの抽出
      for(i_rangang in rangeangle){
        
        ### range Indicatorの算出
        {
          ## 風向に対して一定の範囲について一つの値を持つ指標の算出
          # 実際にあった風向に対してそれぞれ逐次処理
          # Hd, λ'を算出する
          # pb.rngInd <- txtProgressBar(min = 1, max = length(wdlev), style = 3)
          for (i_wd in 1:length(wdlev)) {
            # 範囲の決定
            temp.range <- c(wdlev[i_wd] - i_rangang/2, wdlev[i_wd] + i_rangang/2)
            
            ### 境界範囲（角度, 距離）に含まれる灌木の抽出
            temp.WsiteD.a.range <- extract.shrub.range(temp.WsiteD.d.range,temp.range,c(PCx, PCy))
            
            # 範囲内に灌木があるかないかで場合分け
            if(nrow(temp.WsiteD.a.range) != 0){
              ### 風向に対して一定の範囲について一つの値を持つ指標の算出
              # 風向と角度範囲の記録
              rangeIndicator$wd[i_wd] <- wdlev[i_wd]
              rangeIndicator$ang_range[i_wd] <- i_rangang
              # Hd 
              rangeIndicator$Hd[i_wd] <- cul.hd(temp.WsiteD.a.range, PCx, PCy, temp.range)
              
              # λ'
              i_area <- range.area.monte.carl(r, c(PCx, PCy), temp.range) # 範囲とサイト範囲の重複面積
              rangeIndicator$lambda_dist[i_wd] <- cul.lambda.dist(temp.WsiteD.a.range, PCx, PCy,wdlev[i_wd], i_area)
              # 距離補正しないλ
              rangeIndicator$lambda[i_wd] <- cul.lambda(temp.WsiteD.a.range,wdlev[i_wd], i_area)
              
              
              # 領域について想定される最大面積と実際の面積
              rangeIndicator$maxS[i_wd] <- r^2 * i_rangang / 2
              rangeIndicator$S[i_wd] <- i_area
              
              # 植被率と灌木平均高
              rangeIndicator[i_wd,c("cover","height")] <-
                cul.veg(r,c(PCx,PCy),temp.range,temp.WsiteD.a.range)
            }else{
              rangeIndicator$wd[i_wd] <- wdlev[i_wd]
              rangeIndicator$ang_range[i_wd] <- i_rangang
              
              # Hd 
              rangeIndicator$Hd[i_wd] <- 0
              
              # λ'
              rangeIndicator$lambda_dist[i_wd] <- 0
              # 距離補正しないλ
              rangeIndicator$lambda[i_wd] <- 0
              
              # 領域について想定される最大面積と実際の面積
              i_area <- range.area.monte.carl(r, c(PCx, PCy), temp.range)
              
              rangeIndicator$maxS[i_wd] <- r^2 * i_rangang / 2
              rangeIndicator$S[i_wd] <- i_area
              
              # 植被率と灌木平均高
              rangeIndicator[i_wd,c("cover","height")] <- c(0,0)
            }
            # setTxtProgressBar(pb.rngInd, i_wd)
          }
          
          # print(paste("culed of rangeInd, wd: ",i_wd,"/" ,length(wdlev),
          #             "dist: ",i_dist,"/",length(distrate),", pc: ",i_sitePC,"/",nrow(WPCD),sep = ""))
          
        }
        
        ## range Indicatorの出力
        write.csv(rangeIndicator, 
                  paste(path,"/result/rangeIndicator/",sitename,"_",evname,"_",PC.No,"d",r,"_a",
                        i_rangang * 180 / pi,"rangeIndicator.csv",sep=""),row.names=FALSE)
        
        ## 実際のusに合わせてデータを抽出
        {
          # その時の風向、範囲角度、範囲距離が決まっているので、lineIndicator,rangeIndicatorの値から
          # 条件に一致する値を集計する
          
          # 各時刻のデータをustで切る
          # Arate_lineはlineIndicatorについて、ある角度範囲で有効なデータ数/角度範囲に含まれる直線数
          # nlineはlineIndicatorについて、ある角度範囲にある直線の数(NAの直線含む)
          result.i.r.ang <- createEmptyDf(nrow(temp.WusfD),18,
                                          c("rangang","wd","sf","us",
                                            "Hae","street_dist","street","Arate_line","nline","cover","height",
                                            "Hd","lambda_dist","lambda","maxS_range","S_range",
                                            "M_Okin","M_new"))
          result.i.r.ang$rangang <- i_rangang*180/pi
          result.i.r.ang[,c("wd","sf","us")] <- temp.WusfD

          
          # pb.dat <- txtProgressBar(min = 1, max = nrow(temp.WusfD), style = 3)
          # tic()
          for(i_dat in 1:nrow(temp.WusfD)){
            # 各時刻のusに合わせて
            us <- temp.WusfD$Us[i_dat] # 摩擦速度
            wd <- temp.WusfD$mean3WD[i_dat] # 風向
            wd.range <- c(wd - i_rangang/2, wd + i_rangang/2) # 風向範囲
            ## lineIndicator
            # 風向範囲に該当する直線の指標データを抽出
            temp.line.Inds <- lineIndicator[angle.range.in(lineIndicator$wd,wd.range[1],wd.range[2]),
                                            c("Hae","street_dist","street")]
            # 有効データ率計算
            result.i.r.ang$Arate_line[i_dat] <- sum(!is.na(temp.line.Inds[1]))/nrow(temp.line.Inds[1])
            result.i.r.ang$nline[i_dat] <- nrow(temp.line.Inds[1])
            # 指標を範囲内の直線で平均
            result.i.r.ang[i_dat,c("Hae","street_dist","street")] <- apply(temp.line.Inds,2,mean,na.rm = TRUE)
            ## rangeIndicator
            temp.rng.Inds <- rangeIndicator[rangeIndicator$wd == wd,c("Hd","lambda_dist","lambda","maxS","S")]
            if(nrow(temp.rng.Inds) == 0){
              stop("ERROR: wd doesn't match wd in rangeIndicator")
            }
            result.i.r.ang[i_dat,c("Hd","lambda_dist","lambda","maxS_range","S_range")] <- temp.rng.Inds
            
            ## model indicator
            if(is.na(ust)){
              result.i.r.ang[i_dat,c("M_Okin","M_new")] <- NA
            }else if(us >= ust){
              temp.model <- modelIndicator[modelIndicator$us == us,]
              temp.model <- temp.model[angle.range.in(temp.model$lphi,wd.range[1],wd.range[2]),
                                       c("M_Okin","M_new")]
              ## 範囲で平均する
              Q.okin <- mean(temp.model$M_Okin,na.rm = T)
              Q.new <- mean(temp.model$M_new,na.rm = T)
              
              ## model結果代入
              result.i.r.ang[i_dat,c("M_Okin","M_new")] <- c(Q.okin,Q.new)
            }else{
              result.i.r.ang[i_dat,c("M_Okin","M_new")] <- 0
            }
            
            # print(i_dat)
            # setTxtProgressBar(pb.dat, i_dat)
          }
          # toc()
        }
        
        # ある角度範囲のときの結果をある距離範囲のときの結果に統合
        result <- rbind(result,result.i.r.ang )

      }

    }else{
      ##### 距離範囲に該当する灌木がなかった場合
      temp.WsiteD.d.range <- temp.WsiteD[sh.range,]
        ### streetのみ算出
        # これによって、有効な直線の割合も算出する
        PC <- c(PCx, PCy)
        ## 関数再定義
  
        formals(cul.street.dist)$pc <- PC
        formals(cul.street.dist)$sh.data <- temp.WsiteD.d.range
        formals(cul.street.dist)$ldist <- r
        
        formals(cul.street)$pc <- PC
        formals(cul.street)$sh.data <- temp.WsiteD.d.range
        formals(cul.street)$ldist <- r
        
        # 計算実行
        lineIndicator$wd <- ang.range
  
        lineIndicator$street_dist <- unlist(future_map(ang.range,cul.street.dist))
        lineIndicator$street <- unlist(future_map(ang.range,cul.street))
        
        ### model系の計算
        if(!is.na(ust)){
          # ただひたすらusのときのsfを求めるだけだが・・・やる必要はある
          # あり得るusとwdの組み合わせについてすべて予め計算しておく
          # あるus, wdのペアについて、i_rangangの幅でデータを作成
          # 全データ抽出
          all.wdus <- temp.WusfD[,c("Us","mean3WD")]
          row.names(all.wdus) <- NULL
          all.wdus <- all.wdus[all.wdus$Us >= ust, ]
          # 各wdに対する角度範囲算出
          range <- createEmptyDf(nrow(all.wdus),2,c("ar1","ar2"))
          range$ar1 <- all.wdus$mean3WD - rangeangle[length(rangeangle)]/2
          range$ar2 <- all.wdus$mean3WD + rangeangle[length(rangeangle)]/2
          # range$ar1 <- all.wdus$mean3WD - i_rangang/2
          # range$ar2 <- all.wdus$mean3WD + i_rangang/2
          
          # 各データについてwdを角度範囲に拡張
          formals(expand.wd.range)$byang <- modelbyang
          all.wd <- mapply(expand.wd.range,range$ar1,range$ar2)
          all.us <- mapply(rep, all.wdus$Us,nrow(all.wd)) # usデータもwdの拡張数分増やしておく
          all.wd.ori <- mapply(rep, all.wdus$mean3WD,nrow(all.wd)) # もともとの風向データも保持
          dim(all.wd) <- c(nrow(all.wd) * ncol (all.wd),1) # ベクトル化
          dim(all.us) <- c(nrow(all.us) * ncol (all.us),1) # ベクトル化
          dim(all.wd.ori) <- c(nrow(all.wd.ori) * ncol (all.wd.ori),1) # ベクトル化
          # us, wdの全組み合わせデータフレーム作成
          all.wdus2 <- data.frame(us = all.us, lphi = all.wd,wd = all.wd.ori) 
          # 省メモリ用処理
          rm(all.wdus,all.wd,all.us,all.wd.ori) 
          gc(reset = TRUE)
          gc(reset = TRUE)
          # lphiを-piからpiに変換
          all.wdus2$lphi <- mpi.to.pi(all.wdus2$lphi)
          # 昇順に並べ替え
          all.wdus2 <- all.wdus2[order(all.wdus2$lphi),]
          
          all.wdus2 <- all.wdus2[order(all.wdus2$us),]
          all.wdus2 <- all.wdus2[order(all.wdus2$wd),]
          
          # 重複解除
          all.wdus2 <-all.wdus2 %>% dplyr::distinct(us, lphi,.keep_all=T)
          
          # wdの値をもとにlambda_distを取得してmap計算するためのデータを作成
          formals(which.same.wd)$vec = rangeIndicator$wd
          all.dat.model <- data.frame(lphi = all.wdus2$lphi,us = all.wdus2$us,
                                      lambda =  rangeIndicator[sapply(all.wdus2$wd,which.same.wd),
                                                               "lambda_dist"])
          # 省メモリ用処理
          rm(all.wdus2) 
          gc(reset = TRUE)
          gc(reset = TRUE)
          
          
          ## model計算
          # 初期値調整
          # new用
          formals(cul.model.new)$pc <- c(PCx, PCy)
          formals(cul.model.new)$ldist <- r
          formals(cul.model.new)$shrub.data <-temp.WsiteD.d.range[,2:ncol(temp.WsiteD.d.range)]
          formals(cul.model.new)$ustr <- ust
          
          # okin用
          formals(cul.model.okin)$lambda <- lamb.pc
          formals(cul.model.okin)$pc <- c(PCx, PCy)
          formals(cul.model.okin)$ldist <- r
          formals(cul.model.okin)$aveh <- mean.h
          formals(cul.model.okin)$shrub.data <-temp.WsiteD.d.range[,2:ncol(temp.WsiteD.d.range)]
          formals(cul.model.okin)$ustr <- ust
          
          # map計算
          # tic()
          q.new.line <- future_pmap_dbl(all.dat.model,cul.model.new,.progress = TRUE)
          # toc()
          # tic()
          q.okin.line <- future_pmap_dbl(all.dat.model[,c("lphi","us")],cul.model.okin,.progress = TRUE)
          # toc()
          
          # modelの結果
          modelIndicator <- data.frame(M_Okin = q.okin.line, M_new = q.new.line)
          modelIndicator <- cbind(all.dat.model,modelIndicator)
        }else{
          modelIndicator <- NA
        }
        
      
      ### 結果格納
      result <- createEmptyDf(1,18,
                              c("rangang","wd","sf","us",
                                "Hae","street_dist","street","Arate_line","nline","cover","height",
                                "Hd","lambda_dist","lambda","maxS_range","S_range",
                                "M_Okin","M_new"))[0,]
      for(i_rangang in rangeangle){
        rangeIndicator$wd<- wdlev
        rangeIndicator$ang_range <- i_rangang
        
        # Hd 
        rangeIndicator$Hd <- 0
        
        # λ'
        rangeIndicator$lambda_dist <- 0
        # 距離補正しないλ
        rangeIndicator$lambda <- 0
        # 植被率と灌木平均高
        rangeIndicator[,c("cover","height")] <- 0
        rangeIndicator$maxS <- r^2 * i_rangang / 2
        
        for (i_wd in 1:length(wdlev)) {
          temp.range <- c(wdlev[i_wd] - i_rangang/2, wdlev[i_wd] + i_rangang/2)
          # 領域について想定される最大面積と実際の面積
          i_area <- range.area.monte.carl(r, c(PCx, PCy), temp.range)

          rangeIndicator$S[i_wd] <- i_area
        }
        
        ## range Indicatorの出力
        write.csv(rangeIndicator, 
                  paste(path,"/result/rangeIndicator/",sitename,"_",evname,"_",PC.No,"d",r,"_a",
                        i_rangang * 180 / pi,"rangeIndicator.csv",sep=""),row.names=FALSE)
        
        # あるi_rangangのときの結果について
        result.i.r.ang <- createEmptyDf(nrow(temp.WusfD),18,
                                        c("rangang","wd","sf","us",
                                          "Hae","street_dist","street","Arate_line","nline","cover","height",
                                          "Hd","lambda_dist","lambda","maxS_range","S_range",
                                          "M_Okin","M_new"))
        result.i.r.ang$rangang <- i_rangang*180/pi
        result.i.r.ang[,c("wd","sf","us")] <- temp.WusfD
        for(i_dat in 1:nrow(temp.WusfD)){
          # 各時刻のusに合わせて
          us <- temp.WusfD$Us[i_dat] # 摩擦速度
          wd <- temp.WusfD$mean3WD[i_dat] # 風向
          wd.range <- c(wd - i_rangang/2, wd + i_rangang/2) # 風向範囲
          ## lineIndicator
          # 風向範囲に該当する直線の指標データを抽出
          temp.line.Inds <- lineIndicator[angle.range.in(lineIndicator$wd,wd.range[1],wd.range[2]),
                                          c("Hae","street_dist","street")]
          # 有効データ率計算
          result.i.r.ang$Arate_line[i_dat] <- sum(!is.na(temp.line.Inds[1]))/nrow(temp.line.Inds[1])
          result.i.r.ang$nline[i_dat] <- nrow(temp.line.Inds[1])
          # 指標を範囲内の直線で総和
          result.i.r.ang[i_dat,c("street_dist","street")] <- apply(temp.line.Inds[,2:3],2,sum,na.rm = TRUE)
          
          ## rangeIndicator
          temp.rng.Inds <- rangeIndicator[rangeIndicator$wd == wd,c("Hd","lambda_dist","lambda","maxS","S")]
          if(nrow(temp.rng.Inds) == 0){
            stop("ERROR: wd doesn't match wd in rangeIndicator")
          }
          result.i.r.ang[i_dat,c("Hd","lambda_dist","lambda","maxS_range","S_range")] <- temp.rng.Inds
          
          ## model indicator
          if(is.na(ust)){
            result.i.r.ang[i_dat,c("M_Okin","M_new")] <- NA
          }else if(us >= ust){
            temp.model <- modelIndicator[modelIndicator$us == us,]
            temp.model <- temp.model[angle.range.in(temp.model$lphi,wd.range[1],wd.range[2]),
                                     c("M_Okin","M_new")]
            ## 範囲で平均する
            Q.okin <- mean(temp.model$M_Okin,na.rm = T)
            Q.new <- mean(temp.model$M_new,na.rm = T)
            
            ## model結果代入
            result.i.r.ang[i_dat,c("M_Okin","M_new")] <- c(Q.okin,Q.new)
          }else{
            result.i.r.ang[i_dat,c("M_Okin","M_new")] <- 0
          }

        }
        ## 灌木がないときの値を入力
        # Hea
        result.i.r.ang$Hae <- 0
        result <- rbind(result,result.i.r.ang )

      }
    }
    
    ## line Indicatorの出力
    write.csv(lineIndicator, 
              paste(path,"/result/lineIndicator/",sitename,"_",evname,"_",PC.No,"d",r,"_lineIndicator.csv",sep=""),row.names=FALSE)
    
    ### ある距離範囲のときの結果をあるPCのときの結果に統合
    {
      result$rangdist <- i_dist
      dist.result <- rbind(dist.result,result)
      print(paste("finished dist: ",
                  which(distrate == i_dist),"/",length(distrate),", pc",i_sitePC,"/",nrow(WPCD),sep = ""))
    }

    # setTxtProgressBar(pb.dist, i_dist)
  }
  
  ### あるPCのときの結果を全体の結果に統合
  {
    dist.result$site <- sitename
    dist.result$ev <- evname
    dist.result$pcNo <- PC.No
    dist.result$mean.h <- mean.h
    dist.result$ust <- ust
    
    final.result <- rbind(final.result,dist.result)
    
    print(paste("finished pc:",i_sitePC,"/",nrow(WPCD),sep = ""))
    write.csv(dist.result, paste(path,"/result/",sitename,"_",evname,"_pc",PC.No,"various_indicator.csv",sep=""),row.names=FALSE)
  }
  
  setTxtProgressBar(pb.pc, (i_sitePC - 1) * length(distrate) + which(distrate == i_dist))
}
toc()
# 結果出力
write.csv(final.result, paste(path,"/result/various_indicator.csv",sep=""),row.names=FALSE)































